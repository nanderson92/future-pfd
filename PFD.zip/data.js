const CATEGORY_META = {
  Energy: { color: "#18a999", description: "Generation, storage, fuels, and grid pathways" },
  "Climate Tech": { color: "#4f8f5b", description: "Carbon, cooling, circularity, and environmental systems" },
  Infrastructure: { color: "#2b6cb0", description: "Water, heat, logistics, and public works" },
  "Urban Systems": { color: "#8b6f47", description: "Buildings, cities, and civic-scale deployment" },
  Transportation: { color: "#d0782f", description: "Aircraft, roads, pods, trains, and charging" },
  Manufacturing: { color: "#6f63c7", description: "Factories, printed systems, and process development" },
  Robotics: { color: "#c04d7a", description: "Autonomous machines and physical task execution" },
  Materials: { color: "#3b8bb8", description: "Coatings, membranes, composites, and functional matter" },
  Bio: { color: "#5b9f61", description: "Biological production and living systems" },
  "Medical Tech": { color: "#b84b5f", description: "Therapies, implants, diagnostics, and augmentation" },
  Computing: { color: "#596fba", description: "AI, simulation, displays, and information infrastructure" },
  Space: { color: "#7f66a8", description: "Off-world processing, habitats, and orbital systems" }
};

const PROCESS_PATHWAYS = [
  {
    title: "Better materials",
    text: "Higher-temperature alloys, membranes, catalysts, coatings, and structural composites convert lab effects into durable equipment."
  },
  {
    title: "Cheaper clean energy",
    text: "Electrification, hydrogen, thermal storage, and renewable heat lower the operating cost of energy-intensive future systems."
  },
  {
    title: "Advanced manufacturing",
    text: "Printed electronics, additive metal, roll-to-roll coating, and modular skids make small demonstrations repeatable at scale."
  },
  {
    title: "High-throughput experimentation",
    text: "Automated labs and screening platforms compress discovery cycles for catalysts, materials, cell lines, and process windows."
  },
  {
    title: "Process control and automation",
    text: "Sensors, advanced control, digital twins, and QA feedback loops keep complex systems inside manufacturable operating windows."
  },
  {
    title: "Modular factories",
    text: "Containerized units and standardized interfaces let new technologies scale by replication instead of one-off megaprojects."
  },
  {
    title: "Better separations",
    text: "Membranes, adsorption, crystallization, distillation, and electrochemical separations often decide whether economics work."
  },
  {
    title: "Supply-chain redesign",
    text: "Critical minerals, feedstock logistics, recycled streams, and quality specifications must exist before deployment can grow."
  },
  {
    title: "Policy and infrastructure deployment",
    text: "Permits, codes, utility interconnects, public procurement, and shared infrastructure turn isolated hardware into systems."
  },
  {
    title: "Reliability testing",
    text: "Field exposure, failure-mode analysis, safety cases, and maintenance plans decide whether prototypes can become trusted assets."
  },
  {
    title: "Cost reduction through scale",
    text: "Learning curves, yield improvement, standardization, and utilization rates determine whether technical possibility becomes adoption."
  }
];

const PROCESS_QUESTIONS = {
  cost: "What unit operation dominates cost?",
  scale: "What fails during scale-up?",
  quality: "What quality attribute controls adoption?",
  material: "What material bottleneck prevents deployment?",
  infrastructure: "What infrastructure must exist first?",
  manufacturable: "What makes this manufacturable instead of just possible?"
};

function t(item) {
  return {
    name: item.name,
    category: item.category,
    promise: item.promise,
    realisticPathway: item.realisticPathway,
    pfdSteps: item.pfdSteps,
    inputs: item.inputs,
    outputs: item.outputs,
    bottlenecks: item.bottlenecks,
    readinessGap: item.readinessGap,
    scaleCondition: item.scaleCondition,
    processQuestion: item.processQuestion
  };
}

const technologies = [
  t({
    name: "Fusion power plants",
    category: "Energy",
    promise: "Near-limitless clean energy.",
    realisticPathway: "Plasma confinement, superconducting magnets, tritium breeding, heat extraction, turbine integration, and neutron-tolerant materials.",
    pfdSteps: ["Fuel preparation", "Plasma confinement", "Heat capture", "Power cycle", "Grid integration"],
    inputs: ["Deuterium", "Tritium", "Coolant"],
    outputs: ["Electricity", "Waste heat", "Activated materials"],
    bottlenecks: ["Materials durability", "Tritium supply", "Net-electric economics"],
    readinessGap: "Burning plasma progress has not yet become a maintainable net-electric plant.",
    scaleCondition: "Blankets, magnets, and maintenance cycles must support high availability.",
    processQuestion: PROCESS_QUESTIONS.material
  }),
  t({
    name: "Space-based solar power",
    category: "Energy",
    promise: "Continuous solar power beamed from orbit.",
    realisticPathway: "Ultra-light PV arrays, robotic orbital assembly, wireless power transmission, safe rectenna fields, low launch cost, and grid integration.",
    pfdSteps: ["Solar collection", "DC conversion", "Wireless transmission", "Rectenna capture", "Grid conditioning"],
    inputs: ["Orbital arrays", "Sunlight", "Ground rectennas"],
    outputs: ["Dispatchable electricity", "Thermal losses"],
    bottlenecks: ["Launch economics", "Transmission efficiency", "Orbital maintenance"],
    readinessGap: "The system is plausible in pieces but not as a low-cost orbital utility.",
    scaleCondition: "Launch, assembly, and transmission losses must fall below terrestrial alternatives.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Direct air capture cities",
    category: "Climate Tech",
    promise: "Cities that remove CO2 from the sky.",
    realisticPathway: "Low-energy sorbents, modular air contactors, renewable heat, CO2 purification, compression, storage, utilization, or mineralization.",
    pfdSteps: ["Air intake", "CO2 capture", "Sorbent regeneration", "Purification/compression", "Storage or utilization"],
    inputs: ["Air", "Sorbent", "Clean heat and power"],
    outputs: ["Concentrated CO2", "Cleaned air"],
    bottlenecks: ["Energy demand", "Sorbent degradation", "Cost per ton"],
    readinessGap: "Early plants exist, but city-scale removal needs much cheaper modules and low-carbon energy.",
    scaleCondition: "Capture cost must drop while storage and verification capacity expands.",
    processQuestion: PROCESS_QUESTIONS.cost
  }),
  t({
    name: "Synthetic fuel from air and water",
    category: "Climate Tech",
    promise: "Carbon-neutral jet fuel made from CO2 and water.",
    realisticPathway: "Direct air capture, green hydrogen, catalytic CO2 conversion, methanol or Fischer-Tropsch synthesis, refining, and fuel certification.",
    pfdSteps: ["Air and water intake", "CO2 capture and electrolysis", "Syngas or methanol", "Hydrocarbon synthesis", "Fuel upgrading"],
    inputs: ["CO2", "Water", "Renewable electricity"],
    outputs: ["Drop-in fuel", "Oxygen", "Process heat"],
    bottlenecks: ["Clean hydrogen cost", "Energy intensity", "Fuel certification"],
    readinessGap: "Chemistry is known; economics depend on cheap electricity and high plant utilization.",
    scaleCondition: "Green hydrogen and CO2 must become low-cost, reliable feedstocks.",
    processQuestion: PROCESS_QUESTIONS.cost
  }),
  t({
    name: "Green hydrogen cities",
    category: "Energy",
    promise: "Hydrogen-powered transit, industry, and buildings.",
    realisticPathway: "Cheap electrolyzers, renewable electricity, storage tanks or caverns, pipelines, fuel cells, safety systems, and end-use conversion.",
    pfdSteps: ["Water feed", "Electrolysis", "Compression/storage", "Distribution", "Fuel cell or combustion use"],
    inputs: ["Water", "Renewable power", "Storage hardware"],
    outputs: ["Hydrogen", "Oxygen", "Useful energy"],
    bottlenecks: ["Storage", "Distribution", "Leakage and cost"],
    readinessGap: "Hydrogen is industrially mature, but city-scale clean distribution is not.",
    scaleCondition: "Electrolyzer cost, storage safety, and pipeline compatibility must align.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Green ammonia fuel",
    category: "Energy",
    promise: "Ammonia as a carbon-free shipping and fertilizer fuel.",
    realisticPathway: "Green hydrogen, nitrogen separation, Haber-Bosch or alternative synthesis, cracking or direct combustion, and NOx management.",
    pfdSteps: ["Air separation", "Hydrogen production", "Ammonia synthesis", "Storage/shipping", "Fuel or fertilizer use"],
    inputs: ["Nitrogen", "Green hydrogen", "Power"],
    outputs: ["Ammonia", "Heat", "Fertilizer or fuel"],
    bottlenecks: ["Toxicity", "Combustion control", "Infrastructure"],
    readinessGap: "Production is mature; low-carbon synthesis and safe fuel use need deployment.",
    scaleCondition: "Ports, engines, safety systems, and NOx controls must standardize.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Carbon-negative concrete",
    category: "Materials",
    promise: "Buildings that store atmospheric carbon.",
    realisticPathway: "CO2 capture, mineralization chemistry, alkaline waste feedstocks, low-carbon cement blends, curing control, and structural certification.",
    pfdSteps: ["CO2 source", "Mineralization reactor", "Aggregate/cement formulation", "Controlled curing", "Structural product"],
    inputs: ["CO2", "Alkaline minerals or wastes", "Cementitious binders"],
    outputs: ["Carbon-storing concrete", "Construction products"],
    bottlenecks: ["Strength", "Durability", "Standards and feedstock scale"],
    readinessGap: "Pilot products exist, but broad code acceptance and feedstock logistics lag.",
    scaleCondition: "Carbon storage must be verified without compromising structural performance.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Low-carbon steel",
    category: "Manufacturing",
    promise: "Skyscrapers, vehicles, and infrastructure made without coal.",
    realisticPathway: "Green hydrogen direct reduction, electric arc furnaces, clean electricity, scrap sorting, and low-carbon iron ore processing.",
    pfdSteps: ["Iron ore prep", "Hydrogen reduction", "Sponge iron", "Electric furnace", "Steel finishing"],
    inputs: ["Iron ore", "Green hydrogen", "Clean electricity"],
    outputs: ["Low-carbon steel", "Water vapor", "Slag"],
    bottlenecks: ["Hydrogen supply", "Ore quality", "Electric furnace capacity"],
    readinessGap: "Demonstrations are advancing, but global steel needs massive hydrogen and power scale.",
    scaleCondition: "Green hydrogen must be available at commodity industrial volumes.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Carbon-negative plastics",
    category: "Materials",
    promise: "Plastics made from captured carbon instead of fossil carbon.",
    realisticPathway: "CO2 or biomass feedstocks, catalytic conversion, polymerization, purification, compounding, and recycling loops.",
    pfdSteps: ["CO2 or biomass feed", "Monomer synthesis", "Polymerization", "Extrusion/molding", "Recycling loop"],
    inputs: ["CO2 or biomass", "Catalysts", "Energy"],
    outputs: ["Polymer resin", "Finished plastic", "Recycle stream"],
    bottlenecks: ["Cost", "Catalyst selectivity", "Product performance"],
    readinessGap: "Some polymers can use alternative carbon; broad commodity substitution remains expensive.",
    scaleCondition: "Carbon-derived monomers must meet price and performance targets.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Industrial waste-heat networks",
    category: "Infrastructure",
    promise: "Cities heated by hidden industrial energy.",
    realisticPathway: "Heat exchangers, heat pumps, thermal storage, district heating loops, sensors, and urban retrofits.",
    pfdSteps: ["Waste heat source", "Heat recovery", "Heat pump/storage", "District loop", "Building use"],
    inputs: ["Industrial heat", "Pumps", "Thermal network"],
    outputs: ["Building heat", "Lower fuel demand"],
    bottlenecks: ["Coordination", "Retrofit cost", "Temperature matching"],
    readinessGap: "Technologies are mature, but projects require shared infrastructure planning.",
    scaleCondition: "Cities must coordinate industrial sites, utilities, and building retrofits.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Artificial photosynthesis",
    category: "Energy",
    promise: "Sunlight directly converted into fuel.",
    realisticPathway: "Photoelectrochemical catalysts, membrane separators, water splitting, CO2 reduction, product separation, and stability engineering.",
    pfdSteps: ["Sunlight and feed", "Photoelectrochemical conversion", "Membrane separation", "Fuel polishing", "Storage"],
    inputs: ["Sunlight", "Water", "CO2"],
    outputs: ["Hydrogen or carbon fuel", "Oxygen"],
    bottlenecks: ["Catalyst lifetime", "Efficiency", "Scale-up"],
    readinessGap: "Lab devices work, but stable outdoor fuel modules are not mature.",
    scaleCondition: "Catalysts must survive years while maintaining useful conversion efficiency.",
    processQuestion: PROCESS_QUESTIONS.material
  }),
  t({
    name: "Thermal batteries",
    category: "Energy",
    promise: "Cheap stored heat powering factories and grids.",
    realisticPathway: "Resistive heating with renewables, refractory storage media, heat exchangers, insulated modules, and steam or hot air output.",
    pfdSteps: ["Renewable electricity", "Resistive heating", "Thermal storage", "Heat extraction", "Industrial use"],
    inputs: ["Electricity", "Storage media", "Insulated modules"],
    outputs: ["High-temperature heat", "Steam or hot air"],
    bottlenecks: ["Heat losses", "Materials durability", "Integration"],
    readinessGap: "Commercial systems are emerging; matching heat quality to processes is the adoption hurdle.",
    scaleCondition: "Factories must be able to replace fossil heat without reliability penalties.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Grid-scale flow batteries",
    category: "Energy",
    promise: "Cities stabilized by massive liquid batteries.",
    realisticPathway: "Low-cost electrolytes, membranes, tanks, pumps, power electronics, and long-cycle-life electrochemical stacks.",
    pfdSteps: ["Electrolyte production", "Tank storage", "Electrochemical stack", "Power conversion", "Grid dispatch"],
    inputs: ["Electrolyte", "Membranes", "Electricity"],
    outputs: ["Stored electricity", "Grid services"],
    bottlenecks: ["Electrolyte cost", "Membrane degradation", "System footprint"],
    readinessGap: "Technically fielded, but cost and bankability limit very large deployment.",
    scaleCondition: "Electrolytes and stacks must deliver long life at grid-storage prices.",
    processQuestion: PROCESS_QUESTIONS.cost
  }),
  t({
    name: "Ambient geothermal networks",
    category: "Infrastructure",
    promise: "Neighborhoods heated and cooled by the ground.",
    realisticPathway: "Boreholes, heat pumps, district thermal loops, thermal storage, and building retrofits.",
    pfdSteps: ["Ground loop", "Heat pump", "Thermal distribution", "Building HVAC", "Return loop"],
    inputs: ["Boreholes", "Electricity", "Water or glycol loop"],
    outputs: ["Heating", "Cooling", "Thermal storage"],
    bottlenecks: ["Drilling cost", "Urban deployment", "Retrofit complexity"],
    readinessGap: "Ground-source systems work; district-scale implementation depends on planning and capital.",
    scaleCondition: "Borefield installation must be standardized and financed like utility infrastructure.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Methane pyrolysis for clean hydrogen",
    category: "Energy",
    promise: "Hydrogen with solid carbon instead of CO2 emissions.",
    realisticPathway: "High-temperature reactors, catalyst or plasma systems, carbon separation, hydrogen purification, and solid carbon markets.",
    pfdSteps: ["Methane feed", "Pyrolysis reactor", "Hydrogen separation", "Carbon handling", "End use"],
    inputs: ["Methane", "Heat or plasma power", "Catalyst"],
    outputs: ["Hydrogen", "Solid carbon"],
    bottlenecks: ["Reactor fouling", "Carbon product value", "Heat management"],
    readinessGap: "Processes are promising but need robust continuous carbon removal.",
    scaleCondition: "Solid carbon must become a managed product, not a disposal liability.",
    processQuestion: PROCESS_QUESTIONS.scale
  }),
  t({
    name: "Atmospheric water harvesting",
    category: "Infrastructure",
    promise: "Water pulled from air anywhere.",
    realisticPathway: "Sorbent materials, cooling and condensation, solar or waste-heat regeneration, filtration, remineralization, and storage.",
    pfdSteps: ["Ambient air", "Water capture", "Regeneration/condensation", "Purification", "Storage"],
    inputs: ["Humid air", "Sorbent or condenser", "Energy"],
    outputs: ["Potable water", "Dry air"],
    bottlenecks: ["Energy at low humidity", "Sorbent lifetime", "Throughput"],
    readinessGap: "Small systems exist, but dry-climate water production is energy-limited.",
    scaleCondition: "Capture media must produce useful volumes with low-grade heat or solar power.",
    processQuestion: PROCESS_QUESTIONS.cost
  }),
  t({
    name: "Desalination megastructures",
    category: "Infrastructure",
    promise: "Ocean water converted into abundant freshwater.",
    realisticPathway: "Reverse osmosis, energy recovery, renewable power, membrane cleaning, brine management, and mineral recovery.",
    pfdSteps: ["Seawater intake", "Pretreatment", "RO membranes", "Remineralization", "Distribution"],
    inputs: ["Seawater", "Membranes", "Electricity"],
    outputs: ["Freshwater", "Concentrated brine"],
    bottlenecks: ["Brine disposal", "Energy demand", "Membrane fouling"],
    readinessGap: "Desalination is mature, but megascale ecological and energy impacts must be managed.",
    scaleCondition: "Brine handling and clean power must scale with plant capacity.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Brine mining",
    category: "Materials",
    promise: "Extracting valuable minerals from desalination waste.",
    realisticPathway: "Selective membranes, precipitation, electrochemical separation, evaporation, crystallization, and product purification.",
    pfdSteps: ["Brine feed", "Selective extraction", "Precipitation/crystallization", "Purification", "Mineral products"],
    inputs: ["Concentrated brine", "Reagents", "Electricity"],
    outputs: ["Lithium or salts", "Treated brine"],
    bottlenecks: ["Selectivity", "Economics", "Variable composition"],
    readinessGap: "Minerals are present, but concentrations and separation costs rarely close the loop.",
    scaleCondition: "Selective separations must beat commodity mineral supply chains.",
    processQuestion: PROCESS_QUESTIONS.cost
  }),
  t({
    name: "Self-cleaning city water systems",
    category: "Infrastructure",
    promise: "Pipes and drains that resist fouling.",
    realisticPathway: "Anti-biofouling coatings, embedded sensors, flow optimization, automated flushing, and predictive maintenance.",
    pfdSteps: ["Water flow", "Sensor monitoring", "Fouling detection", "Automated cleaning", "Quality control"],
    inputs: ["Water network", "Sensors", "Cleaning protocols"],
    outputs: ["Cleaner pipes", "Maintenance data"],
    bottlenecks: ["Coating lifetime", "Retrofit cost", "Sensor reliability"],
    readinessGap: "Pieces exist, but buried infrastructure is difficult to retrofit and verify.",
    scaleCondition: "Coatings and sensors must survive decades of real water chemistry.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "PFAS destruction systems",
    category: "Climate Tech",
    promise: "Permanent destruction of forever chemicals.",
    realisticPathway: "Concentration by adsorption or membranes, electrochemical oxidation, plasma treatment, supercritical water oxidation, and verification analytics.",
    pfdSteps: ["Contaminated water", "PFAS concentration", "Destruction reactor", "Polishing", "Discharge verification"],
    inputs: ["PFAS water", "Adsorbent or membrane", "Energy"],
    outputs: ["Treated water", "Destroyed fluorochemicals"],
    bottlenecks: ["Energy use", "Byproduct control", "Analytical verification"],
    readinessGap: "Concentration is common; verified destruction at low cost is still developing.",
    scaleCondition: "Treatment trains must prove mineralization without creating new hazards.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Wastewater-to-drinking-water systems",
    category: "Infrastructure",
    promise: "Closed-loop urban water.",
    realisticPathway: "Membrane bioreactors, reverse osmosis, UV advanced oxidation, activated carbon, real-time monitoring, and public acceptance.",
    pfdSteps: ["Wastewater", "Biological treatment", "Membrane filtration", "Advanced oxidation", "Potable storage"],
    inputs: ["Municipal wastewater", "Membranes", "Oxidants and UV"],
    outputs: ["Potable water", "Concentrate", "Biosolids"],
    bottlenecks: ["Trust", "Monitoring", "Failure-mode safety"],
    readinessGap: "Technically proven, but social trust and monitoring standards determine adoption.",
    scaleCondition: "Real-time QA must make failures visible and containable.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "City-scale nutrient recovery",
    category: "Climate Tech",
    promise: "Sewage transformed into fertilizer.",
    realisticPathway: "Ammonia stripping, struvite precipitation, anaerobic digestion, biosolids treatment, and pathogen control.",
    pfdSteps: ["Wastewater", "Nutrient concentration", "Precipitation/recovery", "Purification", "Fertilizer"],
    inputs: ["Wastewater", "Magnesium or alkali", "Digesters"],
    outputs: ["Fertilizer products", "Biogas", "Cleaner effluent"],
    bottlenecks: ["Contamination", "Product acceptance", "Plant integration"],
    readinessGap: "Recovery systems exist, but fertilizer markets demand consistent quality.",
    scaleCondition: "Recovered products must meet agronomic and contaminant specifications.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Smart stormwater infrastructure",
    category: "Urban Systems",
    promise: "Cities that absorb floods intelligently.",
    realisticPathway: "Permeable surfaces, bioswales, retention tanks, sensors, predictive control, and green roofs.",
    pfdSteps: ["Rainfall", "Distributed capture", "Filtration/storage", "Controlled release", "Reuse or discharge"],
    inputs: ["Rainwater", "Green infrastructure", "Sensors"],
    outputs: ["Reduced flooding", "Stored water", "Cleaner runoff"],
    bottlenecks: ["Land use", "Maintenance", "Hydraulic coordination"],
    readinessGap: "Components are mature; networked control and maintenance funding are uneven.",
    scaleCondition: "Cities must operate stormwater assets as an active distributed system.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Modular emergency water units",
    category: "Infrastructure",
    promise: "Disaster zones instantly supplied with clean water.",
    realisticPathway: "Containerized filtration, solar power, membrane modules, chemical dosing, and sensor-based quality assurance.",
    pfdSteps: ["Local source", "Pretreatment", "Membrane/UV treatment", "Storage", "Distribution"],
    inputs: ["Surface or well water", "Filters", "Solar or generator power"],
    outputs: ["Safe water", "Waste concentrate"],
    bottlenecks: ["Variable feedwaters", "Robustness", "Operator simplicity"],
    readinessGap: "Portable units exist, but disaster reliability depends on maintenance and consumables.",
    scaleCondition: "Units must handle unknown water quality with simple QA signals.",
    processQuestion: PROCESS_QUESTIONS.manufacturable
  }),
  t({
    name: "Closed-loop building water",
    category: "Urban Systems",
    promise: "Skyscrapers that recycle most of their water.",
    realisticPathway: "Greywater separation, membrane filtration, UV disinfection, smart plumbing, and nonpotable reuse loops.",
    pfdSteps: ["Sink/shower water", "Filtration", "Disinfection", "Storage", "Toilet or irrigation reuse"],
    inputs: ["Greywater", "Membranes", "UV systems"],
    outputs: ["Reuse water", "Sludge or concentrate"],
    bottlenecks: ["Plumbing retrofits", "Health codes", "User trust"],
    readinessGap: "New buildings can integrate loops; existing buildings are harder to retrofit.",
    scaleCondition: "Codes and plumbing standards must normalize nonpotable reuse.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Smart glass buildings",
    category: "Materials",
    promise: "Buildings that tint, insulate, and regulate light automatically.",
    realisticPathway: "Electrochromic coatings, transparent conductors, ion-conducting layers, sealing, cycling durability, and building controls.",
    pfdSteps: ["Glass prep", "Conductive coating", "Electrochromic deposition", "Lamination/sealing", "Module testing"],
    inputs: ["Glass", "Conductive oxides", "Electrochromic materials"],
    outputs: ["Smart glazing", "Control data"],
    bottlenecks: ["Coating uniformity", "Cycling durability", "Cost"],
    readinessGap: "Commercial products exist, but cost and large-area reliability limit broad adoption.",
    scaleCondition: "Large panels must hold optical performance through years of cycling.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Self-healing concrete",
    category: "Materials",
    promise: "Roads and buildings that repair cracks.",
    realisticPathway: "Encapsulated healing agents, bacteria-based mineralization, polymer networks, moisture-triggered chemistry, and durability testing.",
    pfdSteps: ["Cement matrix", "Healing additive integration", "Casting", "Crack activation", "Repair reaction"],
    inputs: ["Cement", "Healing agents", "Moisture"],
    outputs: ["Repaired microcracks", "Longer service life"],
    bottlenecks: ["Long-term performance", "Structural certification", "Cost"],
    readinessGap: "Lab and pilot materials are promising; infrastructure codes need field evidence.",
    scaleCondition: "Healing must be predictable under real loads, climates, and maintenance cycles.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Adaptive building skins",
    category: "Urban Systems",
    promise: "Buildings that breathe, shade, cool, and harvest energy.",
    realisticPathway: "Responsive materials, sensors, actuators, solar coatings, thermal storage layers, and control algorithms.",
    pfdSteps: ["Sensor input", "Control system", "Material or actuator response", "Heat/light regulation", "Performance feedback"],
    inputs: ["Sensors", "Facade modules", "Control power"],
    outputs: ["Reduced loads", "Occupant comfort", "Operating data"],
    bottlenecks: ["Reliability", "Maintenance", "Cost"],
    readinessGap: "Architectural prototypes exist, but lifecycle reliability is a barrier.",
    scaleCondition: "Facade modules must be serviceable and energy-positive over their lifetime.",
    processQuestion: PROCESS_QUESTIONS.manufacturable
  }),
  t({
    name: "Radiative cooling materials",
    category: "Climate Tech",
    promise: "Surfaces that cool buildings without electricity.",
    realisticPathway: "Photonic coatings, polymer films, selective infrared emission, weather-resistant layers, and roof or wall integration.",
    pfdSteps: ["Coating formulation", "Film deposition", "Curing", "Installation", "Cooling performance"],
    inputs: ["Polymers", "Pigments", "Roof or wall substrate"],
    outputs: ["Passive cooling", "Lower AC load"],
    bottlenecks: ["Durability", "Dirt and humidity", "Cost"],
    readinessGap: "Materials work in trials; real urban exposure decides energy savings.",
    scaleCondition: "Coatings must stay reflective and emissive after years outdoors.",
    processQuestion: PROCESS_QUESTIONS.material
  }),
  t({
    name: "Transparent solar windows",
    category: "Energy",
    promise: "Skyscrapers that generate power from glass.",
    realisticPathway: "Transparent photovoltaics, spectral-selective absorbers, conductive coatings, module wiring, and building integration.",
    pfdSteps: ["Glass substrate", "Transparent PV coating", "Encapsulation", "Wiring", "Building power interface"],
    inputs: ["Glass", "PV absorbers", "Transparent conductors"],
    outputs: ["Electricity", "Daylighting"],
    bottlenecks: ["Efficiency-transparency tradeoff", "Lifetime", "Wiring integration"],
    readinessGap: "Prototypes exist, but power density is low versus conventional panels.",
    scaleCondition: "Windows must deliver useful energy without compromising daylight or facade life.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "3D-printed buildings",
    category: "Manufacturing",
    promise: "Houses printed by robots.",
    realisticPathway: "Printable cementitious materials, robotic gantries, rheology control, reinforcement integration, codes, and QA.",
    pfdSteps: ["Mix formulation", "Pumping", "Robotic deposition", "Curing", "Reinforcement/finishing"],
    inputs: ["Cement mix", "Robotic gantry", "Reinforcement"],
    outputs: ["Printed shell", "Construction data"],
    bottlenecks: ["Structural reliability", "Code acceptance", "Reinforcement integration"],
    readinessGap: "Printed structures exist, but mainstream construction needs repeatable QA and code pathways.",
    scaleCondition: "Printed walls must meet conventional structural and insurance standards.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Living buildings",
    category: "Bio",
    promise: "Architecture integrated with biology.",
    realisticPathway: "Algae facades, biofilms, controlled growth media, water and nutrient loops, containment, and maintenance protocols.",
    pfdSteps: ["Nutrient/water loop", "Biological growth module", "Light/CO2 exchange", "Biomass harvesting", "Loop control"],
    inputs: ["Water", "Nutrients", "CO2 and light"],
    outputs: ["Biomass", "Shading", "Captured carbon"],
    bottlenecks: ["Biofouling", "Control", "Maintenance"],
    readinessGap: "Demonstrations are visually compelling but operationally fragile.",
    scaleCondition: "Biological modules must be maintainable like building equipment.",
    processQuestion: PROCESS_QUESTIONS.manufacturable
  }),
  t({
    name: "Urban vertical farms",
    category: "Urban Systems",
    promise: "Skyscrapers producing food.",
    realisticPathway: "LED lighting, hydroponics or aeroponics, nutrient recycling, climate control, automation, and crop genetics.",
    pfdSteps: ["Water/nutrients", "Controlled growth", "Monitoring", "Harvest", "Packaging and nutrient recycle"],
    inputs: ["Seeds", "Water", "Electricity and nutrients"],
    outputs: ["Produce", "Plant waste", "Data"],
    bottlenecks: ["Electricity cost", "Crop economics", "Automation"],
    readinessGap: "Leafy greens work best; staple crops are far harder economically.",
    scaleCondition: "Energy and labor costs must fall for broader crop categories.",
    processQuestion: PROCESS_QUESTIONS.cost
  }),
  t({
    name: "Autonomous waste sorting facilities",
    category: "Robotics",
    promise: "Trash transformed into clean material streams.",
    realisticPathway: "Machine vision, robotics, density separation, shredding, washing, polymer identification, and recycling markets.",
    pfdSteps: ["Mixed waste", "Sorting", "Cleaning", "Separation", "Reprocessing"],
    inputs: ["Mixed waste", "Robots", "Wash water"],
    outputs: ["Recovered materials", "Rejects", "Process data"],
    bottlenecks: ["Contamination", "Market value", "Identification accuracy"],
    readinessGap: "Robotic sorting is growing, but feed variability limits purity and economics.",
    scaleCondition: "Recovered streams must meet buyer specifications at high throughput.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Pneumatic waste networks",
    category: "Infrastructure",
    promise: "Cities without garbage trucks.",
    realisticPathway: "Underground vacuum tubes, centralized sorting, odor control, maintenance access, and district-scale deployment.",
    pfdSteps: ["Building waste inlet", "Vacuum transport", "Central collection", "Sorting", "Recycling/disposal"],
    inputs: ["Bagged waste", "Vacuum power", "Tube network"],
    outputs: ["Centralized waste streams", "Reduced truck traffic"],
    bottlenecks: ["Retrofit cost", "Clogging", "Maintenance access"],
    readinessGap: "District systems exist, but retrofitting dense cities is capital-intensive.",
    scaleCondition: "Networks must be designed with buildings, streets, and sorting facilities together.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Underground logistics networks",
    category: "Infrastructure",
    promise: "Packages moving invisibly under cities.",
    realisticPathway: "Autonomous carts, tunnels, routing algorithms, distribution hubs, and maintenance systems.",
    pfdSteps: ["Package intake", "Routing hub", "Underground transport", "Local delivery node", "Customer handoff"],
    inputs: ["Packages", "Tunnels", "Autonomous carriers"],
    outputs: ["Delivered goods", "Traffic reduction"],
    bottlenecks: ["Excavation cost", "Interoperability", "Maintenance"],
    readinessGap: "Automation is feasible; civil works and network rights are the hard part.",
    scaleCondition: "Tunnel deployment must cost less than surface logistics congestion.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Modular megastructure cities",
    category: "Urban Systems",
    promise: "Plug-and-play urban expansion.",
    realisticPathway: "Prefabricated modules, standardized utility interfaces, structural connectors, logistics, and codes.",
    pfdSteps: ["Module fabrication", "Transport", "Utility connection", "Structural assembly", "Commissioning"],
    inputs: ["Prefab modules", "Utility interfaces", "Cranes and logistics"],
    outputs: ["Habitable units", "Connected services"],
    bottlenecks: ["Standardization", "Permitting", "Transport limits"],
    readinessGap: "Modular construction exists; city-scale plug-and-play standards do not.",
    scaleCondition: "Interfaces must become as standardized as shipping containers.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Climate-controlled pedestrian corridors",
    category: "Urban Systems",
    promise: "Walkable cities protected from extreme weather.",
    realisticPathway: "District energy, passive design, shading, evaporative cooling, air filtration, and modular canopy systems.",
    pfdSteps: ["Outdoor corridor", "Shade/air handling", "Cooling/filtration", "Sensor control", "Pedestrian environment"],
    inputs: ["Canopy modules", "Thermal energy", "Sensors"],
    outputs: ["Comfortable walkways", "Filtered air"],
    bottlenecks: ["Capital cost", "Maintenance", "Energy use"],
    readinessGap: "Elements are proven; continuous public-space systems need civic funding.",
    scaleCondition: "Corridors must improve mobility enough to justify operating cost.",
    processQuestion: PROCESS_QUESTIONS.cost
  }),
  t({
    name: "City-scale digital twins",
    category: "Computing",
    promise: "Cities simulated and optimized in real time.",
    realisticPathway: "Sensor networks, GIS, building data, traffic models, utility data, simulation platforms, and governance.",
    pfdSteps: ["Sensors/data", "Integration platform", "Simulation model", "Decision support", "Operations"],
    inputs: ["City sensors", "GIS data", "Utility and traffic feeds"],
    outputs: ["Operational forecasts", "Planning scenarios"],
    bottlenecks: ["Data interoperability", "Privacy", "Model trust"],
    readinessGap: "Digital twins exist in fragments; whole-city governance remains immature.",
    scaleCondition: "Data standards and privacy rules must support cross-agency operations.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Urban heat-island reversal systems",
    category: "Climate Tech",
    promise: "Cities that actively cool themselves.",
    realisticPathway: "Reflective materials, tree canopy, water features, cool pavements, district cooling, and thermal mapping.",
    pfdSteps: ["Thermal mapping", "Surface/material intervention", "Cooling deployment", "Monitoring", "Adjustment"],
    inputs: ["Thermal data", "Cool materials", "Vegetation and water"],
    outputs: ["Lower surface temperatures", "Reduced cooling load"],
    bottlenecks: ["Maintenance", "Neighborhood coordination", "Water availability"],
    readinessGap: "Known interventions need coordinated deployment at neighborhood scale.",
    scaleCondition: "Cooling measures must be measured, maintained, and equitably distributed.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Flying cars / eVTOL air taxis",
    category: "Transportation",
    promise: "Personal aerial mobility.",
    realisticPathway: "High-density batteries, distributed electric propulsion, autonomous avionics, vertiports, air traffic management, and noise reduction.",
    pfdSteps: ["Battery charging", "Flight control", "Electric propulsion", "Vertiport operations", "Maintenance"],
    inputs: ["Electricity", "Battery packs", "Airspace data"],
    outputs: ["Passenger trips", "Noise and maintenance data"],
    bottlenecks: ["Energy density", "Safety", "Airspace management"],
    readinessGap: "Aircraft are nearing certification, but network operations remain unproven.",
    scaleCondition: "Vehicles, vertiports, and traffic control must reach airline-grade reliability.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Hyperloop-style transport",
    category: "Transportation",
    promise: "Ultra-fast tube transportation.",
    realisticPathway: "Low-pressure tubes, magnetic levitation, linear motors, vacuum pumps, safety systems, and thermal expansion control.",
    pfdSteps: ["Pod loading", "Evacuated tube", "Propulsion/levitation", "Braking", "Station handling"],
    inputs: ["Passengers or cargo", "Low-pressure tubes", "Electric power"],
    outputs: ["High-speed trips", "Heat and vacuum loads"],
    bottlenecks: ["Infrastructure cost", "Emergency safety", "Thermal expansion"],
    readinessGap: "Subsystem demos exist; full corridor safety and economics are unresolved.",
    scaleCondition: "Tube construction and emergency procedures must beat existing rail or air options.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Autonomous electric transit pods",
    category: "Transportation",
    promise: "Personalized public transit.",
    realisticPathway: "Batteries, charging networks, autonomy stacks, route optimization, fleet management, and maintenance hubs.",
    pfdSteps: ["Passenger request", "Fleet routing", "Vehicle dispatch", "Charging/maintenance", "Data feedback"],
    inputs: ["Trip demand", "EV pods", "Route data"],
    outputs: ["Passenger mobility", "Fleet data"],
    bottlenecks: ["Autonomy reliability", "Urban integration", "Fleet utilization"],
    readinessGap: "Shuttles operate in limited domains; mixed urban traffic is harder.",
    scaleCondition: "Autonomy must handle edge cases while fleet economics remain favorable.",
    processQuestion: PROCESS_QUESTIONS.scale
  }),
  t({
    name: "Hydrogen aircraft",
    category: "Transportation",
    promise: "Zero-carbon flight.",
    realisticPathway: "Liquid hydrogen storage, cryogenic tanks, fuel cells or turbines, airport fueling systems, and safety certification.",
    pfdSteps: ["Hydrogen production", "Liquefaction", "Airport storage", "Aircraft fueling", "Propulsion"],
    inputs: ["Green hydrogen", "Cryogenic tanks", "Airport infrastructure"],
    outputs: ["Flight power", "Water vapor", "Boiloff losses"],
    bottlenecks: ["Volumetric energy density", "Infrastructure", "Certification"],
    readinessGap: "Components exist, but aircraft design and airport fuel systems must change together.",
    scaleCondition: "Cryogenic fueling must become routine, safe, and fast at airports.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Electric aviation",
    category: "Transportation",
    promise: "Quiet zero-emission regional aircraft.",
    realisticPathway: "High-energy batteries, lightweight structures, thermal management, fast charging, and short-haul route design.",
    pfdSteps: ["Grid power", "Fast charging", "Battery storage", "Electric propulsion", "Thermal management"],
    inputs: ["Electricity", "Batteries", "Lightweight airframe"],
    outputs: ["Short-haul flight", "Battery heat"],
    bottlenecks: ["Battery specific energy", "Charging speed", "Payload range"],
    readinessGap: "Small aircraft are feasible; larger regional missions need better batteries.",
    scaleCondition: "Battery packs must improve without compromising cycle life and safety.",
    processQuestion: PROCESS_QUESTIONS.material
  }),
  t({
    name: "Maglev trains",
    category: "Transportation",
    promise: "Frictionless ultra-fast ground travel.",
    realisticPathway: "Superconducting or electromagnetic levitation, guideway infrastructure, power electronics, and control systems.",
    pfdSteps: ["Grid power", "Levitation/propulsion", "Vehicle control", "Station operations", "Maintenance"],
    inputs: ["Guideway", "Electricity", "Control systems"],
    outputs: ["High-speed transport", "Grid demand"],
    bottlenecks: ["Guideway cost", "Network deployment", "Right-of-way"],
    readinessGap: "Maglev works technically; deployment is dominated by capital planning.",
    scaleCondition: "Corridor demand must justify dedicated guideway investment.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Self-healing roads",
    category: "Materials",
    promise: "Roads that repair themselves.",
    realisticPathway: "Asphalt binders with microcapsules, induction heating materials, recycled polymers, and embedded sensors.",
    pfdSteps: ["Asphalt formulation", "Road paving", "Damage sensing", "Healing activation", "Performance monitoring"],
    inputs: ["Asphalt", "Healing additives", "Sensors or heating"],
    outputs: ["Extended pavement life", "Maintenance alerts"],
    bottlenecks: ["Cost", "Field validation", "Additive durability"],
    readinessGap: "Materials work in trials; lifecycle economics must beat conventional resurfacing.",
    scaleCondition: "Healing performance must persist under traffic, weather, and maintenance.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Robotic construction fleets",
    category: "Robotics",
    promise: "Cities built by autonomous machines.",
    realisticPathway: "Autonomous earthmoving, robotic layout, concrete printing, machine vision, BIM integration, and safety controls.",
    pfdSteps: ["Digital design", "Robotic site prep", "Automated construction", "Inspection", "Handoff"],
    inputs: ["BIM model", "Robots", "Construction materials"],
    outputs: ["Built assets", "Inspection data"],
    bottlenecks: ["Unstructured sites", "Safety", "System integration"],
    readinessGap: "Robots handle specific tasks, but full construction sites change constantly.",
    scaleCondition: "Autonomy must be reliable around people, weather, and material variability.",
    processQuestion: PROCESS_QUESTIONS.scale
  }),
  t({
    name: "Smart highways",
    category: "Transportation",
    promise: "Roads that communicate with vehicles.",
    realisticPathway: "Embedded sensors, V2X communication, dynamic signage, charging lanes, and predictive maintenance.",
    pfdSteps: ["Road sensors", "Data network", "Vehicle communication", "Traffic/control response", "Maintenance feedback"],
    inputs: ["Sensors", "Vehicles", "Communication network"],
    outputs: ["Traffic optimization", "Maintenance alerts"],
    bottlenecks: ["Standardization", "Cybersecurity", "Retrofit cost"],
    readinessGap: "Pilot corridors exist, but national interoperability is immature.",
    scaleCondition: "Vehicle and infrastructure standards must converge.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Wireless road charging",
    category: "Infrastructure",
    promise: "EVs charging while driving.",
    realisticPathway: "Inductive coils, power electronics, vehicle receivers, billing systems, and grid upgrades.",
    pfdSteps: ["Grid power", "Roadside coils", "Vehicle receiver", "Battery charging", "Billing/control"],
    inputs: ["Electricity", "Embedded coils", "Vehicle receivers"],
    outputs: ["Vehicle charge", "Grid load data"],
    bottlenecks: ["Efficiency", "Cost", "Interoperability"],
    readinessGap: "Demonstrations work; deployment depends on road construction economics.",
    scaleCondition: "Charging lanes must be shared, efficient, and compatible across vehicles.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Autonomous factories",
    category: "Manufacturing",
    promise: "Factories that run themselves.",
    realisticPathway: "Robotics, machine vision, sensors, process control, digital twins, predictive maintenance, and human oversight.",
    pfdSteps: ["Raw material intake", "Automated processing", "Inspection", "Packaging", "Feedback control"],
    inputs: ["Raw materials", "Robots", "Sensors"],
    outputs: ["Finished goods", "Quality data"],
    bottlenecks: ["Exception handling", "System integration", "Maintenance"],
    readinessGap: "Automated lines exist, but fully autonomous mixed production is rare.",
    scaleCondition: "Systems must recover from abnormal conditions without hiding risk.",
    processQuestion: PROCESS_QUESTIONS.scale
  }),
  t({
    name: "Factory-in-a-box",
    category: "Manufacturing",
    promise: "Deployable microfactories anywhere.",
    realisticPathway: "Modular process skids, standard utilities, automation, QA modules, and containerized production.",
    pfdSteps: ["Feedstock", "Modular process unit", "Inspection", "Packaged product", "Service loop"],
    inputs: ["Feedstock", "Utility hookups", "Skid modules"],
    outputs: ["Local products", "QA records"],
    bottlenecks: ["Flexibility vs. QA", "Utility variability", "Throughput"],
    readinessGap: "Containerized systems work for narrow products; flexible manufacturing is harder.",
    scaleCondition: "Modules must maintain validated quality across deployment sites.",
    processQuestion: PROCESS_QUESTIONS.manufacturable
  }),
  t({
    name: "Self-replicating manufacturing systems",
    category: "Manufacturing",
    promise: "Machines that build more machines.",
    realisticPathway: "Modular robotics, standardized parts, additive manufacturing, supply-chain libraries, and automated assembly.",
    pfdSteps: ["Raw materials", "Part fabrication", "Assembly", "Calibration", "Replication"],
    inputs: ["Materials", "Part libraries", "Assembly robots"],
    outputs: ["Machine modules", "Calibration data"],
    bottlenecks: ["Complexity", "Precision", "Component diversity"],
    readinessGap: "Partial automation exists, but complete replication needs broad component supply.",
    scaleCondition: "Machines must fabricate enough of their own precision components to matter.",
    processQuestion: PROCESS_QUESTIONS.manufacturable
  }),
  t({
    name: "Molecular assemblers",
    category: "Manufacturing",
    promise: "Atomically precise manufacturing.",
    realisticPathway: "Scanning probe systems, DNA origami, molecular machines, self-assembly, and nanolithography.",
    pfdSteps: ["Molecular feedstocks", "Directed assembly", "Error correction", "Product stabilization", "Scale-out"],
    inputs: ["Molecules", "Templates", "Energy"],
    outputs: ["Nanostructures", "Assembly defects"],
    bottlenecks: ["Speed", "Error rates", "Scale"],
    readinessGap: "Precision exists in research tools, not high-throughput production.",
    scaleCondition: "Assembly must become massively parallel with reliable defect correction.",
    processQuestion: PROCESS_QUESTIONS.scale
  }),
  t({
    name: "Programmable matter",
    category: "Materials",
    promise: "Materials that change shape or function on command.",
    realisticPathway: "Metamaterials, embedded actuation, responsive polymers, microelectronics, and distributed control.",
    pfdSteps: ["Material fabrication", "Actuator integration", "Sensing/control", "Shape response", "Reset"],
    inputs: ["Responsive materials", "Microelectronics", "Power"],
    outputs: ["Reconfigurable form", "Control data"],
    bottlenecks: ["Power delivery", "Manufacturability", "Control complexity"],
    readinessGap: "Programmable structures exist at small scales; useful macro products remain limited.",
    scaleCondition: "Actuation, sensing, and power must be manufacturable inside the material.",
    processQuestion: PROCESS_QUESTIONS.manufacturable
  }),
  t({
    name: "Swarm robotics",
    category: "Robotics",
    promise: "Fleets of small robots building or repairing environments.",
    realisticPathway: "Low-cost robots, distributed algorithms, localization, charging, task coordination, and fault tolerance.",
    pfdSteps: ["Task input", "Swarm coordination", "Local action", "Feedback", "Mission update"],
    inputs: ["Robot fleet", "Task map", "Power"],
    outputs: ["Distributed work", "Status data"],
    bottlenecks: ["Messy environments", "Localization", "Fault tolerance"],
    readinessGap: "Swarm demos exist; real-world reliability and task value are uneven.",
    scaleCondition: "Individual failures must not collapse mission performance.",
    processQuestion: PROCESS_QUESTIONS.scale
  }),
  t({
    name: "Robotic maintenance cities",
    category: "Robotics",
    promise: "Robots constantly repairing infrastructure.",
    realisticPathway: "Inspection drones, crawling robots, machine vision, repair materials, and scheduling systems.",
    pfdSteps: ["Inspection", "Defect detection", "Repair dispatch", "Material application", "Verification"],
    inputs: ["Infrastructure assets", "Inspection robots", "Repair materials"],
    outputs: ["Repaired defects", "Asset condition data"],
    bottlenecks: ["Uncontrolled environments", "Repair quality", "Access"],
    readinessGap: "Inspection is advancing faster than autonomous repair.",
    scaleCondition: "Robotic repairs must meet the same standards as human crews.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Additive manufacturing of metal parts",
    category: "Manufacturing",
    promise: "Complex metal parts printed on demand.",
    realisticPathway: "Powder production, laser or electron-beam melting, thermal control, in-situ monitoring, post-processing, and qualification.",
    pfdSteps: ["Metal powder", "Layer deposition", "Melting", "Heat treatment", "Inspection/certification"],
    inputs: ["Metal powder", "Laser or beam energy", "Inert gas"],
    outputs: ["Qualified parts", "Scrap powder", "Inspection data"],
    bottlenecks: ["Defects", "Repeatability", "Qualification"],
    readinessGap: "High-value parts are real; commodity substitution needs faster, cheaper, certified processes.",
    scaleCondition: "In-situ QA must predict part performance without excessive testing.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Roll-to-roll printed electronics",
    category: "Manufacturing",
    promise: "Electronics printed like newspapers.",
    realisticPathway: "Conductive inks, flexible substrates, coating and printing tools, drying or sintering, registration control, and inspection.",
    pfdSteps: ["Ink formulation", "Substrate prep", "Printing/coating", "Curing/sintering", "Testing"],
    inputs: ["Conductive inks", "Flexible substrate", "Thermal or photonic curing"],
    outputs: ["Flexible circuits", "Defect maps"],
    bottlenecks: ["Defect density", "Resolution", "Registration"],
    readinessGap: "Specific devices are manufacturable; dense high-performance electronics are harder.",
    scaleCondition: "Printing yield must meet electronics-grade defect limits.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Micromodular printed electronics",
    category: "Manufacturing",
    promise: "Microelectronic devices assembled like printable components.",
    realisticPathway: "Microdevice fabrication, release into inks, controlled deposition, substrate boundary control, printed interconnects, and inspection.",
    pfdSteps: ["Microdevice fabrication", "Release/ink formulation", "Droplet deposition", "Interconnect printing", "Circuit testing"],
    inputs: ["Microdevices", "Carrier inks", "Substrates"],
    outputs: ["Hybrid circuits", "Rejected placements"],
    bottlenecks: ["Placement control", "Yield", "Interconnect reliability"],
    readinessGap: "Promising for hybrid electronics, but precision placement at speed is difficult.",
    scaleCondition: "Deposition tools must place devices accurately with high throughput.",
    processQuestion: PROCESS_QUESTIONS.scale
  }),
  t({
    name: "AI-guided process development",
    category: "Computing",
    promise: "AI discovering optimal manufacturing recipes.",
    realisticPathway: "High-throughput experiments, sensors, Bayesian optimization, physics-informed models, and automated labs.",
    pfdSteps: ["Experiment design", "Automated testing", "Data capture", "Model update", "New recipe"],
    inputs: ["Process variables", "Experimental platform", "Sensor data"],
    outputs: ["Optimized recipes", "Process models"],
    bottlenecks: ["Data quality", "Scale transfer", "Model trust"],
    readinessGap: "Optimization tools work, but plant transfer requires mechanistic understanding.",
    scaleCondition: "Lab data must predict pilot and production behavior.",
    processQuestion: PROCESS_QUESTIONS.scale
  }),
  t({
    name: "Lights-out semiconductor fabs",
    category: "Manufacturing",
    promise: "Fully automated chip factories.",
    realisticPathway: "Wafer automation, metrology, contamination control, advanced process control, and predictive maintenance.",
    pfdSteps: ["Wafer input", "Lithography/etch/deposition", "Metrology", "Feedback control", "Packaging"],
    inputs: ["Wafers", "Process gases", "Ultra-clean tools"],
    outputs: ["Chips", "Yield data", "Waste chemicals"],
    bottlenecks: ["Yield learning", "Tool complexity", "Contamination control"],
    readinessGap: "Fabs are highly automated, but process learning still needs deep human engineering.",
    scaleCondition: "Automation must accelerate yield learning without reducing process insight.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "On-demand pharmaceutical factories",
    category: "Medical Tech",
    promise: "Medicines manufactured locally when needed.",
    realisticPathway: "Continuous manufacturing, modular reactors, PAT sensors, quality-by-design, and regulatory validation.",
    pfdSteps: ["Raw materials", "Continuous synthesis", "Purification", "Formulation", "QA release"],
    inputs: ["Drug precursors", "Solvents", "PAT sensors"],
    outputs: ["Finished medicine", "Batch records"],
    bottlenecks: ["Regulatory approval", "Robustness", "Cleaning validation"],
    readinessGap: "Continuous pharma is real, but local flexible production needs validated controls.",
    scaleCondition: "Quality release must be fast, automated, and regulator-trusted.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Modular biomanufacturing",
    category: "Bio",
    promise: "Organisms producing chemicals anywhere.",
    realisticPathway: "Engineered microbes, fermentation, downstream processing, sterilization, and modular bioreactors.",
    pfdSteps: ["Feedstock", "Fermentation", "Cell removal", "Purification", "Product formulation"],
    inputs: ["Sugars or gases", "Microbes", "Sterile media"],
    outputs: ["Bioproduct", "Biomass", "Spent media"],
    bottlenecks: ["Contamination", "Yield", "Downstream cost"],
    readinessGap: "Fermentation scales well for some products; many targets lose economics downstream.",
    scaleCondition: "Titers, rates, yields, and purification must beat petrochemical routes.",
    processQuestion: PROCESS_QUESTIONS.cost
  }),
  t({
    name: "Self-optimizing chemical plants",
    category: "Manufacturing",
    promise: "Chemical plants that tune themselves.",
    realisticPathway: "Sensors, advanced process control, digital twins, optimization, safety constraints, and operator oversight.",
    pfdSteps: ["Feedstocks", "Reactor/separation train", "Sensors", "Control algorithm", "Adjusted operation"],
    inputs: ["Feedstocks", "Process data", "Control models"],
    outputs: ["Products", "Setpoint changes", "Alarms"],
    bottlenecks: ["Safety", "Model reliability", "Edge cases"],
    readinessGap: "Advanced control is common, but autonomous optimization is constrained by safety cases.",
    scaleCondition: "Models must be accurate enough to optimize without violating safety margins.",
    processQuestion: PROCESS_QUESTIONS.scale
  }),
  t({
    name: "Graphene membranes",
    category: "Materials",
    promise: "Ultra-fast water purification and gas separation.",
    realisticPathway: "Scalable graphene synthesis, defect control, membrane support layers, module fabrication, and fouling control.",
    pfdSteps: ["Carbon source", "Graphene growth", "Transfer/support", "Pore engineering", "Module assembly"],
    inputs: ["Carbon precursor", "Support membrane", "Etching tools"],
    outputs: ["Separation modules", "Reject stream"],
    bottlenecks: ["Defect-free scale-up", "Fouling", "Module sealing"],
    readinessGap: "Exceptional lab transport must become defect-controlled square meters.",
    scaleCondition: "Membranes must be produced with controlled pores and low defect density.",
    processQuestion: PROCESS_QUESTIONS.material
  }),
  t({
    name: "Carbon nanotube elevators / cables",
    category: "Materials",
    promise: "Ultra-strong cables for space elevators or megastructures.",
    realisticPathway: "Long CNT fiber spinning, alignment, defect reduction, load transfer, and composite processing.",
    pfdSteps: ["CNT synthesis", "Purification", "Fiber spinning", "Alignment/densification", "Cable testing"],
    inputs: ["Carbon feedstock", "CNT reactors", "Binders"],
    outputs: ["CNT fibers", "Composite cables"],
    bottlenecks: ["Macroscale strength", "Defects", "Load transfer"],
    readinessGap: "Lab materials are strong, but long cables fall far below theoretical strength.",
    scaleCondition: "Fiber strength must survive kilometers of defects and joining.",
    processQuestion: PROCESS_QUESTIONS.material
  }),
  t({
    name: "Smart clothing",
    category: "Materials",
    promise: "Clothing that monitors health and adapts temperature.",
    realisticPathway: "Flexible sensors, conductive fibers, washable electronics, low-power modules, and data systems.",
    pfdSteps: ["Fiber/textile prep", "Sensor integration", "Encapsulation", "Garment assembly", "Data interface"],
    inputs: ["Textiles", "Sensors", "Flexible batteries"],
    outputs: ["Wearable data", "Thermal response"],
    bottlenecks: ["Durability", "Washability", "Comfort"],
    readinessGap: "Wearables exist; seamless textile integration is still fragile.",
    scaleCondition: "Electronics must survive washing, bending, sweat, and daily use.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Exoskeleton suits",
    category: "Robotics",
    promise: "Wearable strength enhancement.",
    realisticPathway: "Lightweight actuators, batteries, sensors, control algorithms, ergonomics, and safety systems.",
    pfdSteps: ["User sensing", "Control logic", "Actuator response", "Mechanical assistance", "Feedback"],
    inputs: ["User motion", "Actuators", "Battery power"],
    outputs: ["Assisted movement", "Biomechanics data"],
    bottlenecks: ["Battery mass", "Comfort", "Control"],
    readinessGap: "Industrial and medical exoskeletons exist, but broad everyday use is limited.",
    scaleCondition: "Assistance must be comfortable enough to wear for full shifts.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Cloaking materials",
    category: "Materials",
    promise: "Invisibility or optical camouflage.",
    realisticPathway: "Metamaterials, adaptive displays, cameras, light-field control, and flexible substrates.",
    pfdSteps: ["Environmental sensing", "Optical computation", "Surface emission/reflection", "Camouflage effect", "Feedback"],
    inputs: ["Cameras", "Metasurfaces", "Display power"],
    outputs: ["Reduced visibility", "Heat and data load"],
    bottlenecks: ["Broadband performance", "Viewing angles", "Power"],
    readinessGap: "Narrow-band effects exist; practical all-angle invisibility is far away.",
    scaleCondition: "Optical control must work across wavelengths, angles, and real backgrounds.",
    processQuestion: PROCESS_QUESTIONS.material
  }),
  t({
    name: "Metamaterial sound control",
    category: "Materials",
    promise: "Rooms, vehicles, and cities with engineered silence.",
    realisticPathway: "Acoustic metamaterial panels, resonator arrays, additive manufacturing, and building integration.",
    pfdSteps: ["Material design", "Resonator fabrication", "Panel assembly", "Installation", "Acoustic tuning"],
    inputs: ["Acoustic design", "Printed panels", "Mounting hardware"],
    outputs: ["Noise reduction", "Tuned acoustic response"],
    bottlenecks: ["Bandwidth", "Cost", "Aesthetics"],
    readinessGap: "Targeted panels work; broadband thin solutions are harder.",
    scaleCondition: "Panels must reduce real noise while fitting architectural constraints.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Self-cleaning surfaces",
    category: "Materials",
    promise: "Windows, buildings, and vehicles that stay clean.",
    realisticPathway: "Hydrophobic or photocatalytic coatings, durable binders, surface texture, and UV activation.",
    pfdSteps: ["Surface prep", "Coating deposition", "Curing", "Field exposure", "Cleaning action"],
    inputs: ["Substrate", "Coating chemistry", "UV or water"],
    outputs: ["Cleaner surface", "Degraded contaminants"],
    bottlenecks: ["Abrasion", "Durability", "Soiling variability"],
    readinessGap: "Products exist, but long-term outdoor performance is inconsistent.",
    scaleCondition: "Coatings must survive abrasion, weather, and cleaning chemicals.",
    processQuestion: PROCESS_QUESTIONS.material
  }),
  t({
    name: "Anti-icing materials",
    category: "Materials",
    promise: "Aircraft, roads, and power lines resisting ice.",
    realisticPathway: "Icephobic coatings, heating elements, surface textures, and phase-change materials.",
    pfdSteps: ["Surface prep", "Coating/heater integration", "Environmental exposure", "Ice prevention/removal", "Inspection"],
    inputs: ["Surface", "Coatings or heaters", "Power if active"],
    outputs: ["Reduced ice accretion", "Safety data"],
    bottlenecks: ["Durability", "Harsh conditions", "Energy use"],
    readinessGap: "Many coatings work in tests, but severe weather and abrasion reduce life.",
    scaleCondition: "Materials must perform under real icing, erosion, UV, and maintenance.",
    processQuestion: PROCESS_QUESTIONS.material
  }),
  t({
    name: "Aerogel insulation cities",
    category: "Materials",
    promise: "Ultra-insulated lightweight buildings and vehicles.",
    realisticPathway: "Silica or polymer aerogel production, drying processes, composite panels, fire safety, and cost reduction.",
    pfdSteps: ["Sol-gel formation", "Aging", "Drying", "Composite integration", "Panel installation"],
    inputs: ["Silica or polymer precursors", "Solvents", "Drying energy"],
    outputs: ["Aerogel panels", "Insulated envelopes"],
    bottlenecks: ["Brittleness", "Manufacturing cost", "Fire and moisture performance"],
    readinessGap: "Aerogels are commercial but too expensive for universal building use.",
    scaleCondition: "Panel manufacturing must lower cost while preserving insulation value.",
    processQuestion: PROCESS_QUESTIONS.cost
  }),
  t({
    name: "Shape-shifting materials",
    category: "Materials",
    promise: "Objects that morph on demand.",
    realisticPathway: "Shape-memory alloys or polymers, embedded heaters, soft robotics, and control systems.",
    pfdSteps: ["Material fabrication", "Actuator programming", "Stimulus input", "Shape response", "Reset"],
    inputs: ["Shape-memory material", "Heat or field input", "Controls"],
    outputs: ["Morphed geometry", "Fatigue data"],
    bottlenecks: ["Speed", "Fatigue", "Energy use"],
    readinessGap: "Actuating materials are real, but robust large motions are application-specific.",
    scaleCondition: "Repeated shape change must be fast, efficient, and fatigue-resistant.",
    processQuestion: PROCESS_QUESTIONS.material
  }),
  t({
    name: "Self-healing polymers",
    category: "Materials",
    promise: "Products that repair scratches and cracks.",
    realisticPathway: "Dynamic covalent bonds, microcapsules, supramolecular networks, and thermal or light activation.",
    pfdSteps: ["Polymer synthesis", "Healing chemistry integration", "Product forming", "Damage activation", "Repair"],
    inputs: ["Monomers", "Healing agents", "Stimulus energy"],
    outputs: ["Repaired polymer", "Longer product life"],
    bottlenecks: ["Strength vs. healing", "Activation conditions", "Aging"],
    readinessGap: "Coatings are closer than structural plastics.",
    scaleCondition: "Healing must not sacrifice mechanical strength or processing speed.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Transparent displays everywhere",
    category: "Computing",
    promise: "Glass surfaces acting as screens.",
    realisticPathway: "Transparent OLEDs, microLEDs, conductive films, encapsulation, and power/data integration.",
    pfdSteps: ["Glass/substrate", "Transparent electronics", "Emissive layer", "Encapsulation", "Display integration"],
    inputs: ["Glass", "Emitters", "Transparent conductors"],
    outputs: ["Transparent display", "Heat and data load"],
    bottlenecks: ["Brightness", "Transparency", "Lifetime"],
    readinessGap: "Displays exist, but durable architectural integration is limited.",
    scaleCondition: "Panels must be bright, transparent, repairable, and power-efficient.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Holographic interfaces",
    category: "Computing",
    promise: "3D displays floating in space.",
    realisticPathway: "Light-field displays, volumetric displays, spatial light modulators, and eye tracking.",
    pfdSteps: ["3D data", "Optical computation", "Light modulation", "Volumetric/light-field projection", "User feedback"],
    inputs: ["3D scene data", "Optics", "Compute"],
    outputs: ["3D visual field", "Heat"],
    bottlenecks: ["Resolution", "Brightness", "Compute load"],
    readinessGap: "Niche systems exist; consumer-scale high-resolution volume is hard.",
    scaleCondition: "Optics and compute must deliver bright 3D imagery without bulky hardware.",
    processQuestion: PROCESS_QUESTIONS.cost
  }),
  t({
    name: "Room-temperature superconductors",
    category: "Materials",
    promise: "Lossless power grids, levitation, and compact magnets.",
    realisticPathway: "Materials discovery, high-throughput synthesis, pressure-free stability, and wire or tape manufacturing.",
    pfdSteps: ["Material synthesis", "Phase stabilization", "Wire fabrication", "Property testing", "Device integration"],
    inputs: ["Precursors", "Synthesis equipment", "Characterization tools"],
    outputs: ["Superconducting forms", "Validated property data"],
    bottlenecks: ["Verified properties", "Manufacturable form", "Current density"],
    readinessGap: "No broadly verified ambient superconductor exists for engineering deployment.",
    scaleCondition: "A stable material must be independently verified and manufacturable as wire or tape.",
    processQuestion: PROCESS_QUESTIONS.material
  }),
  t({
    name: "Bio-inspired structural materials",
    category: "Materials",
    promise: "Lightweight materials as strong as shells, bone, or spider silk.",
    realisticPathway: "Hierarchical composites, additive manufacturing, biomimetic assembly, and fiber alignment.",
    pfdSteps: ["Material formulation", "Hierarchical structuring", "Curing/consolidation", "Testing", "Product"],
    inputs: ["Fibers", "Matrix materials", "Structuring process"],
    outputs: ["Lightweight composite", "Performance data"],
    bottlenecks: ["Scalable hierarchy", "Defect control", "Cost"],
    readinessGap: "We can mimic pieces of nature; industrial hierarchy control is the bottleneck.",
    scaleCondition: "Manufacturing must control structure across nano, micro, and macro scales.",
    processQuestion: PROCESS_QUESTIONS.manufacturable
  }),
  t({
    name: "Lab-grown organs",
    category: "Medical Tech",
    promise: "Replacement organs grown on demand.",
    realisticPathway: "Stem cells, scaffolds, vascularization, bioreactors, immune compatibility, and quality control.",
    pfdSteps: ["Patient cells", "Differentiation", "Scaffold seeding", "Bioreactor culture", "Maturation/testing"],
    inputs: ["Patient cells", "Growth factors", "Scaffolds"],
    outputs: ["Tissue construct", "QC data"],
    bottlenecks: ["Vascularization", "Functional integration", "Sterility"],
    readinessGap: "Simple tissues are closer; full organs require vascular and functional complexity.",
    scaleCondition: "Organs must mature with perfusion, function, and patient-specific compatibility.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Cultivated meat",
    category: "Bio",
    promise: "Meat without animals.",
    realisticPathway: "Cell lines, growth media, bioreactors, scaffolding, downstream structuring, and food safety.",
    pfdSteps: ["Cell culture", "Proliferation", "Differentiation", "Structuring", "Harvesting/packaging"],
    inputs: ["Cell lines", "Growth media", "Bioreactors"],
    outputs: ["Cultivated meat", "Spent media"],
    bottlenecks: ["Media cost", "Texture", "Bioreactor scale"],
    readinessGap: "Products exist at limited scale; price and structure remain difficult.",
    scaleCondition: "Media, bioreactors, and scaffolds must reach food-scale economics.",
    processQuestion: PROCESS_QUESTIONS.cost
  }),
  t({
    name: "Personalized medicine factories",
    category: "Medical Tech",
    promise: "Therapies made specifically for one patient.",
    realisticPathway: "Genomic data, cell processing, automated biomanufacturing, rapid QA, and cold-chain logistics.",
    pfdSteps: ["Patient sample", "Genetic/cellular processing", "Expansion", "Formulation", "QA and treatment"],
    inputs: ["Patient sample", "Genomic data", "Sterile consumables"],
    outputs: ["Personal therapy", "Release data"],
    bottlenecks: ["Cost", "QA speed", "Regulation"],
    readinessGap: "Personalized therapies exist but remain expensive and operationally complex.",
    scaleCondition: "Autologous workflows must become automated, closed, and rapidly releasable.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Neural interfaces",
    category: "Medical Tech",
    promise: "Direct brain-computer communication.",
    realisticPathway: "Implantable electrodes, biocompatible materials, signal processing, wireless power/data, and surgical methods.",
    pfdSteps: ["Neural signal", "Electrode capture", "Signal processing", "Command output", "Feedback"],
    inputs: ["Neural activity", "Implant electrodes", "Decoder models"],
    outputs: ["Digital commands", "Neural feedback"],
    bottlenecks: ["Biocompatibility", "Signal stability", "Surgery risk"],
    readinessGap: "Clinical systems exist for narrow uses; long-term high-bandwidth interfaces are early.",
    scaleCondition: "Interfaces must remain stable and safe for years.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Artificial limbs with touch feedback",
    category: "Medical Tech",
    promise: "Prosthetics that feel natural.",
    realisticPathway: "Sensors, haptics, neural interfaces, lightweight actuators, and adaptive control.",
    pfdSteps: ["User intent", "Signal capture", "Actuator movement", "Sensor feedback", "Neural/haptic response"],
    inputs: ["User signals", "Prosthetic actuators", "Touch sensors"],
    outputs: ["Assisted motion", "Tactile feedback"],
    bottlenecks: ["Interface reliability", "Affordability", "Comfort"],
    readinessGap: "Advanced prototypes work, but cost and fitting complexity limit access.",
    scaleCondition: "Feedback systems must become robust, serviceable, and reimbursable.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Anti-aging therapies",
    category: "Medical Tech",
    promise: "Dramatically extended healthy lifespan.",
    realisticPathway: "Senolytics, gene therapies, regenerative medicine, biomarkers, and controlled trials.",
    pfdSteps: ["Biomarker diagnosis", "Targeted therapy", "Monitoring", "Adjustment", "Long-term outcomes"],
    inputs: ["Patient biomarkers", "Therapeutic agents", "Clinical data"],
    outputs: ["Healthspan outcomes", "Safety data"],
    bottlenecks: ["Biological complexity", "Safety", "Trial duration"],
    readinessGap: "Specific age-related mechanisms are targetable, but broad lifespan extension is unproven.",
    scaleCondition: "Therapies must show durable benefit without unacceptable long-term risk.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Synthetic blood",
    category: "Medical Tech",
    promise: "Universal artificial blood supply.",
    realisticPathway: "Oxygen carriers, hemoglobin engineering, particle stabilization, sterility, and transfusion safety.",
    pfdSteps: ["Hemoglobin/carrier synthesis", "Stabilization", "Purification", "Formulation", "Clinical use"],
    inputs: ["Oxygen carriers", "Stabilizers", "Sterile process"],
    outputs: ["Blood substitute", "Safety data"],
    bottlenecks: ["Safety", "Circulation time", "Side effects"],
    readinessGap: "The need is clear, but oxygen delivery without toxicity is hard.",
    scaleCondition: "Products must oxygenate tissue without triggering vascular or immune harm.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Medical nanobots",
    category: "Medical Tech",
    promise: "Tiny machines repairing the body.",
    realisticPathway: "Targeted nanoparticles, drug delivery vehicles, micro/nanorobots, imaging guidance, and biodegradability.",
    pfdSteps: ["Nanocarrier fabrication", "Targeting functionalization", "Injection", "Navigation/accumulation", "Therapy release"],
    inputs: ["Nanocarriers", "Targeting ligands", "Imaging guidance"],
    outputs: ["Localized therapy", "Clearance products"],
    bottlenecks: ["Control", "Safety", "Clearance"],
    readinessGap: "Targeted delivery exists; autonomous repair robots are still speculative.",
    scaleCondition: "Particles must localize, act, and clear with predictable safety.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Organ-on-chip drug testing",
    category: "Medical Tech",
    promise: "Replacing animal testing with human-like micro-organs.",
    realisticPathway: "Microfluidics, cell culture, sensors, tissue models, and standardized assays.",
    pfdSteps: ["Chip fabrication", "Cell seeding", "Fluid perfusion", "Drug dosing", "Sensor readout"],
    inputs: ["Microfluidic chips", "Human cells", "Drug candidates"],
    outputs: ["Response data", "Toxicity signals"],
    bottlenecks: ["Biological validity", "Standardization", "Throughput"],
    readinessGap: "Useful models exist, but regulatory substitution needs validation.",
    scaleCondition: "Assays must be reproducible across labs and predictive of human outcomes.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Cybernetic implants",
    category: "Medical Tech",
    promise: "Enhanced human capabilities.",
    realisticPathway: "Biocompatible electronics, wireless power, neural/sensor integration, and regulatory approval.",
    pfdSteps: ["Implant fabrication", "Sterilization", "Surgical integration", "Signal/control loop", "Monitoring"],
    inputs: ["Implant hardware", "Power/data link", "Surgical workflow"],
    outputs: ["Enhanced function", "Health monitoring data"],
    bottlenecks: ["Safety", "Ethics", "Long-term reliability"],
    readinessGap: "Medical implants are real; elective enhancement faces technical and ethical barriers.",
    scaleCondition: "Long-term safety and consent frameworks must be stronger than novelty demand.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Quantum computers",
    category: "Computing",
    promise: "Solving impossible computational problems.",
    realisticPathway: "Stable qubits, error correction, cryogenics, control electronics, and scalable fabrication.",
    pfdSteps: ["Qubit fabrication", "Cryogenic operation", "Gate control", "Error correction", "Computation output"],
    inputs: ["Qubits", "Cryogenic systems", "Control electronics"],
    outputs: ["Quantum computation", "Error syndromes"],
    bottlenecks: ["Error rates", "Scaling", "Fabrication yield"],
    readinessGap: "Noisy systems exist; fault-tolerant useful machines need many more reliable qubits.",
    scaleCondition: "Error correction overhead must become manufacturable and economical.",
    processQuestion: PROCESS_QUESTIONS.scale
  }),
  t({
    name: "Neuromorphic computing",
    category: "Computing",
    promise: "Brain-like efficient AI hardware.",
    realisticPathway: "Memristors, analog circuits, spiking networks, semiconductor integration, and new software stacks.",
    pfdSteps: ["Device fabrication", "Synaptic array integration", "Training/inference", "Output", "Model update"],
    inputs: ["Memristive devices", "Semiconductor wafers", "AI workloads"],
    outputs: ["Low-power inference", "Device drift data"],
    bottlenecks: ["Manufacturability", "Programming models", "Device variability"],
    readinessGap: "Research chips exist; software and foundry integration lag mainstream hardware.",
    scaleCondition: "Devices must be reliable enough for standard chip manufacturing.",
    processQuestion: PROCESS_QUESTIONS.manufacturable
  }),
  t({
    name: "AI assistants embedded everywhere",
    category: "Computing",
    promise: "Ambient intelligent environments.",
    realisticPathway: "Edge computing, sensors, privacy-preserving AI, energy-efficient chips, and interoperability.",
    pfdSteps: ["Sensor data", "Edge processing", "AI model", "Action/recommendation", "Feedback"],
    inputs: ["Sensors", "Edge chips", "User context"],
    outputs: ["Actions", "Recommendations", "Audit logs"],
    bottlenecks: ["Privacy", "Trust", "Energy and standards"],
    readinessGap: "Assistants are widespread, but safe ambient integration needs governance.",
    scaleCondition: "Systems must be useful while minimizing surveillance and failure risk.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Fully immersive VR worlds",
    category: "Computing",
    promise: "Realistic alternate realities.",
    realisticPathway: "Displays, optics, haptics, low-latency rendering, spatial audio, and motion tracking.",
    pfdSteps: ["User tracking", "Rendering engine", "Display/haptics/audio", "Sensory feedback", "Session adaptation"],
    inputs: ["Headset sensors", "Graphics compute", "Haptic devices"],
    outputs: ["Immersive experience", "Motion data"],
    bottlenecks: ["Comfort", "Realism", "Latency"],
    readinessGap: "VR is real, but full-body realism and long-duration comfort remain limited.",
    scaleCondition: "Hardware must become lighter, lower-latency, and socially acceptable.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Augmented reality cities",
    category: "Computing",
    promise: "Digital information overlaid on the physical city.",
    realisticPathway: "AR glasses, mapping, localization, edge computing, visual interfaces, and safety standards.",
    pfdSteps: ["Spatial map", "User localization", "Content rendering", "Display overlay", "Interaction"],
    inputs: ["City maps", "Wearables", "Edge compute"],
    outputs: ["Context overlays", "Interaction data"],
    bottlenecks: ["Wearable hardware", "Social acceptance", "Safety"],
    readinessGap: "AR works on phones and some headsets; everyday city use needs better hardware.",
    scaleCondition: "Glasses must be useful, comfortable, private, and safe in public.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Universal real-time translation",
    category: "Computing",
    promise: "Language barriers disappearing.",
    realisticPathway: "Speech recognition, neural translation, low-latency inference, context modeling, and wearable devices.",
    pfdSteps: ["Speech input", "Recognition", "Translation model", "Speech synthesis", "User output"],
    inputs: ["Audio", "Language models", "Device compute"],
    outputs: ["Translated speech", "Transcripts"],
    bottlenecks: ["Nuance", "Latency", "Privacy"],
    readinessGap: "Translation is powerful but still fails in culture, domain, and noisy context.",
    scaleCondition: "Systems must preserve meaning, privacy, and timing in real conversations.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Autonomous scientific discovery",
    category: "Computing",
    promise: "AI labs discovering new materials and drugs.",
    realisticPathway: "Robotic labs, high-throughput experiments, active learning, simulation, and automated characterization.",
    pfdSteps: ["Hypothesis generation", "Robotic experiment", "Characterization", "Model update", "Next experiment"],
    inputs: ["Hypotheses", "Robotic lab", "Characterization tools"],
    outputs: ["Candidate materials or drugs", "Experimental data"],
    bottlenecks: ["Physical-world data quality", "Transferability", "Automation scope"],
    readinessGap: "Closed-loop labs work in focused domains; general discovery remains human-guided.",
    scaleCondition: "Automation must produce trustworthy data faster than human-led iteration.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Digital immortality / mind archives",
    category: "Computing",
    promise: "Preserving a person digitally.",
    realisticPathway: "Data capture, personal AI models, memory archives, behavior modeling, and ethical boundaries.",
    pfdSteps: ["Personal data", "Model training", "Behavior simulation", "Interaction engine", "Archive interface"],
    inputs: ["Personal records", "Voice/video/data", "AI models"],
    outputs: ["Interactive archive", "Consent records"],
    bottlenecks: ["Identity", "Consent", "Fidelity and ethics"],
    readinessGap: "AI likenesses are possible; personhood and continuity are not engineering claims.",
    scaleCondition: "Consent, provenance, and limits must be explicit before systems are trusted.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Lunar oxygen production",
    category: "Space",
    promise: "Moon bases making their own oxygen.",
    realisticPathway: "Regolith processing, molten electrolysis or reduction chemistry, oxygen separation, and storage.",
    pfdSteps: ["Regolith mining", "Chemical reduction/electrolysis", "Oxygen separation", "Liquefaction/storage", "Habitat or propellant use"],
    inputs: ["Lunar regolith", "Power", "Reactors"],
    outputs: ["Oxygen", "Metal-rich residue"],
    bottlenecks: ["Dust handling", "Energy supply", "Autonomous maintenance"],
    readinessGap: "The chemistry is plausible; lunar industrial operation is unproven.",
    scaleCondition: "Systems must run through dust, thermal cycling, and limited maintenance.",
    processQuestion: PROCESS_QUESTIONS.scale
  }),
  t({
    name: "Mars fuel production",
    category: "Space",
    promise: "Making rocket fuel on Mars.",
    realisticPathway: "Atmospheric CO2 capture, water mining, electrolysis, Sabatier reaction, and methane/oxygen liquefaction.",
    pfdSteps: ["CO2 and water", "Electrolysis", "Sabatier reactor", "Methane/oxygen storage", "Vehicle fueling"],
    inputs: ["Martian CO2", "Water ice", "Power"],
    outputs: ["Methane", "Oxygen", "Water recycle"],
    bottlenecks: ["Autonomous reliability", "Water access", "Power"],
    readinessGap: "Subscale oxygen production was demonstrated; full propellant plants remain future systems.",
    scaleCondition: "Plants must produce and store propellant before crew arrival without repair crews.",
    processQuestion: PROCESS_QUESTIONS.scale
  }),
  t({
    name: "Closed-loop life support",
    category: "Space",
    promise: "Self-sustaining habitats.",
    realisticPathway: "Water recycling, air revitalization, food growth, waste processing, and microbial control.",
    pfdSteps: ["Human waste/CO2", "Recovery systems", "Water/oxygen/food", "Habitat loop", "Monitoring"],
    inputs: ["Crew waste", "CO2", "Power and consumables"],
    outputs: ["Water", "Oxygen", "Food or biomass"],
    bottlenecks: ["Reliability", "Biological control", "Trace contaminants"],
    readinessGap: "ISS systems recover much, but fully closed long-duration loops are not solved.",
    scaleCondition: "Loops must tolerate failures and microbial shifts for years.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Space habitats",
    category: "Space",
    promise: "Orbiting cities.",
    realisticPathway: "Modular structures, radiation shielding, closed-loop systems, artificial gravity concepts, and orbital logistics.",
    pfdSteps: ["Module fabrication", "Launch/assembly", "Life-support integration", "Shielding", "Operations"],
    inputs: ["Habitat modules", "Launch capacity", "Life-support systems"],
    outputs: ["Habitable volume", "Waste streams", "Operational data"],
    bottlenecks: ["Launch mass", "Closed-loop reliability", "Radiation"],
    readinessGap: "Stations exist; city-scale habitats need cheaper logistics and robust loops.",
    scaleCondition: "Launch and maintenance costs must fall while life support becomes highly reliable.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Asteroid mining",
    category: "Space",
    promise: "Metals mined from space.",
    realisticPathway: "Prospecting, robotic capture or mining, in-space processing, material transport, and market development.",
    pfdSteps: ["Asteroid survey", "Extraction", "Beneficiation", "Refining", "Transport/use"],
    inputs: ["Target asteroid", "Mining robots", "Processing power"],
    outputs: ["Metals or volatiles", "In-space feedstocks"],
    bottlenecks: ["Economics", "Autonomous mining", "Transport"],
    readinessGap: "Prospecting is possible; profitable extraction is not yet demonstrated.",
    scaleCondition: "In-space demand must justify extraction before Earth-return economics do.",
    processQuestion: PROCESS_QUESTIONS.cost
  }),
  t({
    name: "Orbital manufacturing",
    category: "Space",
    promise: "Products made better in microgravity.",
    realisticPathway: "Autonomous manufacturing platforms, feedstock launch, in-space process control, and return logistics.",
    pfdSteps: ["Feedstock launch", "Microgravity processing", "Inspection", "Return or orbital use", "Learning loop"],
    inputs: ["Feedstock", "Orbital platform", "Power"],
    outputs: ["Microgravity products", "Inspection data"],
    bottlenecks: ["Market demand", "Process control", "Return logistics"],
    readinessGap: "Experiments are real; commercial demand and repeatability are uncertain.",
    scaleCondition: "Microgravity must create a product valuable enough to pay for logistics.",
    processQuestion: PROCESS_QUESTIONS.cost
  }),
  t({
    name: "Space elevators",
    category: "Space",
    promise: "Cheap access to orbit via cable.",
    realisticPathway: "Ultra-strong materials, orbital dynamics, climber power systems, and anchor infrastructure.",
    pfdSteps: ["Cable material production", "Deployment", "Climber operation", "Orbital transfer", "Maintenance"],
    inputs: ["Ultra-strong cable", "Anchor station", "Climbers"],
    outputs: ["Payload to orbit", "Cable stress data"],
    bottlenecks: ["Material strength", "Deployment risk", "Debris impacts"],
    readinessGap: "Required cable performance is beyond current manufacturable materials.",
    scaleCondition: "Materials must achieve enormous specific strength at practical length and reliability.",
    processQuestion: PROCESS_QUESTIONS.material
  }),
  t({
    name: "Terraforming concepts",
    category: "Space",
    promise: "Transforming planets into Earth-like worlds.",
    realisticPathway: "Currently speculative; would require planetary-scale atmospheric engineering, energy input, volatile management, biology, and thousands of years.",
    pfdSteps: ["Resource assessment", "Atmospheric modification", "Thermal control", "Water cycling", "Biosphere introduction"],
    inputs: ["Planetary volatiles", "Massive energy", "Long-term governance"],
    outputs: ["Altered climate", "Ecological risk"],
    bottlenecks: ["Scale", "Ethics", "Time and energy"],
    readinessGap: "This is planetary engineering speculation, not near-term infrastructure.",
    scaleCondition: "Societies would need energy, ethics, and time horizons far beyond current projects.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  }),
  t({
    name: "Replicator-like food machines",
    category: "Manufacturing",
    promise: "Food generated on demand.",
    realisticPathway: "Ingredient cartridges, 3D food printing, flavor chemistry, texture engineering, and heating/cooling modules.",
    pfdSteps: ["Ingredient storage", "Dosing/mixing", "Structuring/printing", "Cooking", "Serving"],
    inputs: ["Ingredient cartridges", "Water", "Heat"],
    outputs: ["Prepared food", "Spent cartridges"],
    bottlenecks: ["Texture", "Ingredient stability", "Cost"],
    readinessGap: "Food printers exist, but broad culinary replacement is not close.",
    scaleCondition: "Cartridge logistics and texture control must beat conventional cooking convenience.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Household recycling machines",
    category: "Manufacturing",
    promise: "Homes converting waste into usable material.",
    realisticPathway: "Sorting, shredding, washing, polymer identification, extrusion, and safety systems.",
    pfdSteps: ["Waste input", "Sorting", "Cleaning", "Shredding", "Pellet/filament output"],
    inputs: ["Household waste", "Water", "Small extruder"],
    outputs: ["Pellets or filament", "Rejects"],
    bottlenecks: ["Contamination", "Energy use", "Safety"],
    readinessGap: "Small recyclers exist, but household waste streams are too messy for reliable products.",
    scaleCondition: "Input sorting must become simple enough for non-experts.",
    processQuestion: PROCESS_QUESTIONS.manufacturable
  }),
  t({
    name: "Smart mirrors / health rooms",
    category: "Medical Tech",
    promise: "Bathrooms that monitor health daily.",
    realisticPathway: "Optical sensors, biosensors, AI interpretation, and privacy-preserving data systems.",
    pfdSteps: ["User scan/sample", "Sensor readout", "AI analysis", "Health feedback", "Clinical escalation"],
    inputs: ["Images", "Vitals or samples", "AI models"],
    outputs: ["Health insights", "Trend data"],
    bottlenecks: ["Accuracy", "Privacy", "Regulation"],
    readinessGap: "Consumer sensors are common, but clinical-grade home interpretation is limited.",
    scaleCondition: "Measurements must be accurate enough to help without overdiagnosis.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Personal air filtration bubbles",
    category: "Medical Tech",
    promise: "Clean-air zones around individuals.",
    realisticPathway: "Wearable filtration, airflow control, low-noise fans, sensors, and battery systems.",
    pfdSteps: ["Ambient air", "Filtration", "Directed flow", "Breathing zone", "Sensor feedback"],
    inputs: ["Ambient air", "Filters", "Battery power"],
    outputs: ["Cleaner breathing zone", "Used filters"],
    bottlenecks: ["Comfort", "Battery", "Effectiveness"],
    readinessGap: "Wearable filtration is possible, but invisible protective bubbles are airflow-hard.",
    scaleCondition: "Airflow must protect users without noise, bulk, or high power.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Home robots",
    category: "Robotics",
    promise: "Robot assistants doing chores.",
    realisticPathway: "Manipulation, perception, navigation, low-cost actuators, and safe human-robot interaction.",
    pfdSteps: ["Task recognition", "Motion planning", "Manipulation", "Feedback", "Task completion"],
    inputs: ["Home environment", "Robot hardware", "Task model"],
    outputs: ["Completed chores", "Learning data"],
    bottlenecks: ["Dexterity", "Reliability", "Cost"],
    readinessGap: "Vacuuming is solved; general household manipulation is not.",
    scaleCondition: "Robots must handle messy homes with low failure rates and safe behavior.",
    processQuestion: PROCESS_QUESTIONS.scale
  }),
  t({
    name: "Universal fabrication appliances",
    category: "Manufacturing",
    promise: "Households making objects on demand.",
    realisticPathway: "Multi-material 3D printing, tool-changing robotics, digital part libraries, and recycling feedstock.",
    pfdSteps: ["Digital design", "Material selection", "Fabrication", "Finishing", "Recycling"],
    inputs: ["Design files", "Material cartridges", "Fabrication tools"],
    outputs: ["Household objects", "Scrap recycle"],
    bottlenecks: ["Materials variety", "Safety", "Precision"],
    readinessGap: "3D printers are useful, but universal object fabrication needs more materials and finishing.",
    scaleCondition: "Appliances must make safe, precise parts from standardized materials.",
    processQuestion: PROCESS_QUESTIONS.manufacturable
  }),
  t({
    name: "Personal climate-control clothing",
    category: "Materials",
    promise: "Clothing that heats or cools the body.",
    realisticPathway: "Phase-change materials, thermoelectrics, microfluidics, flexible batteries, and smart textiles.",
    pfdSteps: ["Body/temp sensing", "Thermal module response", "Heat transfer", "Comfort control", "Recharge/reset"],
    inputs: ["Smart textile", "Battery", "Thermal materials"],
    outputs: ["Comfort control", "Heat rejection"],
    bottlenecks: ["Battery life", "Comfort", "Washability"],
    readinessGap: "Heated apparel exists; active cooling in soft clothing is harder.",
    scaleCondition: "Thermal systems must be light, washable, quiet, and energy-efficient.",
    processQuestion: PROCESS_QUESTIONS.quality
  }),
  t({
    name: "Adaptive furniture / shape-changing rooms",
    category: "Robotics",
    promise: "Rooms reconfiguring themselves.",
    realisticPathway: "Modular robotics, soft actuators, embedded rails, sensors, and control systems.",
    pfdSteps: ["User input", "Spatial planning", "Actuator control", "Furniture movement", "Safety check"],
    inputs: ["Room map", "Actuated furniture", "Sensors"],
    outputs: ["Reconfigured space", "Safety state"],
    bottlenecks: ["Cost", "Safety", "Mechanical reliability"],
    readinessGap: "Transforming furniture exists; autonomous whole-room reconfiguration is niche.",
    scaleCondition: "Moving modules must be quiet, safe, durable, and worth the floor-space tradeoff.",
    processQuestion: PROCESS_QUESTIONS.manufacturable
  }),
  t({
    name: "Personal drone assistants",
    category: "Robotics",
    promise: "Small drones that follow and help users.",
    realisticPathway: "Lightweight batteries, perception, autonomy, noise reduction, safety cages, and regulations.",
    pfdSteps: ["User command", "Flight planning", "Task execution", "Charging dock", "Maintenance"],
    inputs: ["User commands", "Drone hardware", "Battery"],
    outputs: ["Aerial assistance", "Flight data"],
    bottlenecks: ["Safety", "Noise", "Regulation"],
    readinessGap: "Drones are capable, but indoor/public personal use faces safety and nuisance barriers.",
    scaleCondition: "Drones must become quiet, collision-safe, and legally acceptable around people.",
    processQuestion: PROCESS_QUESTIONS.infrastructure
  })
];

const SECTOR_META = {
  "Clean Energy Civilization": {
    code: "A",
    color: "#67e8f9",
    thesis: "Power, fuels, storage, and grids that make future infrastructure energetically possible."
  },
  "Carbon and Atmospheric Engineering": {
    code: "B",
    color: "#62d1bd",
    thesis: "CO2, methane, heat, and atmospheric chemistry converted into managed industrial streams."
  },
  "Future Water Systems": {
    code: "C",
    color: "#5aa7ff",
    thesis: "Water capture, purification, reuse, contaminant destruction, and mineral recovery loops."
  },
  "Future Materials and Smart Surfaces": {
    code: "D",
    color: "#bdb5ff",
    thesis: "Functional materials, membranes, coatings, composites, glass, and adaptive surfaces."
  },
  "Advanced Manufacturing and Microfactories": {
    code: "E",
    color: "#f0a06d",
    thesis: "Factories, fabs, skids, printed systems, robotic production, and autonomous process development."
  },
  "Future Cities and Built Environments": {
    code: "F",
    color: "#f3bfdc",
    thesis: "Buildings, districts, waste, logistics, heat, food, and urban operating systems."
  },
  "Transportation and Mobility": {
    code: "G",
    color: "#ffb36b",
    thesis: "Aircraft, roads, rail, shipping, charging, fuels, and city mobility infrastructure."
  },
  "Biomanufacturing, Medicine, and Human Augmentation": {
    code: "H",
    color: "#89d777",
    thesis: "Cells, therapies, organs, cultivated food, biosensors, and controlled biological production."
  },
  "Computing, Semiconductors, and Ambient Intelligence": {
    code: "I",
    color: "#8ea0ff",
    thesis: "Chips, displays, AI infrastructure, quantum systems, sensors, and scientific automation."
  },
  "Space and Off-World Industry": {
    code: "J",
    color: "#a67cff",
    thesis: "ISRU, habitats, orbital manufacturing, life support, and autonomous off-world plants."
  }
};

const MASTER_STACK = [
  {
    title: "Planetary / local resources",
    detail: "Air, water, minerals, biomass, waste, sunlight, CO2, industrial heat",
    tags: ["Resources", "Feedstocks", "Waste streams"]
  },
  {
    title: "Primary conversion systems",
    detail: "Electrolysis, air separation, mining, refining, fermentation, capture, purification",
    tags: ["Conversion", "Purification", "Capture"]
  },
  {
    title: "Platform chemicals + materials",
    detail: "H2, NH3, methanol, syngas, silicon, lithium salts, polymers, metals, CO2, O2, N2",
    tags: ["Intermediates", "Bulk materials", "Energy carriers"]
  },
  {
    title: "Advanced materials + devices",
    detail: "Batteries, smart glass, membranes, sensors, catalysts, chips, coatings, composites",
    tags: ["Devices", "Materials", "Performance"]
  },
  {
    title: "Manufacturing systems",
    detail: "Fabs, microfactories, bioreactors, additive manufacturing, roll-to-roll lines, modular plants",
    tags: ["MRL", "Yield", "Quality"]
  },
  {
    title: "Infrastructure systems",
    detail: "Grids, water loops, hydrogen networks, smart buildings, transit, data centers, circular waste",
    tags: ["Deployment", "Maintenance", "Safety"]
  },
  {
    title: "Future worlds",
    detail: "Clean cities, autonomous factories, resilient neighborhoods, space habitats, carbon-negative infrastructure",
    tags: ["Cities", "Industry", "Off-world"]
  },
  {
    title: "Feedback loops",
    detail: "Recycling, data, quality control, reliability testing, process optimization, policy, economics",
    tags: ["Learning", "Controls", "Scale"]
  }
];

function chem(name, formula, role, madeFrom, processPathway, enables, bottlenecks, unitOperations) {
  return { name, formula, role, madeFrom, processPathway, enables, bottlenecks, unitOperations, relatedTechnologies: [] };
}

const CHEMICAL_SPINE = [
  chem("Hydrogen", "H2", "Energy carrier for steel, ammonia, synthetic fuels, aircraft, fuel cells, and propellant.", "Water electrolysis or methane reforming/pyrolysis", ["Water feed", "Electrolysis", "Purification", "Compression/liquefaction", "Distribution"], ["Green hydrogen cities", "Green ammonia fuel", "Low-carbon steel", "Synthetic fuel from air and water"], ["Clean electricity cost", "Storage density", "Leakage and safety"], ["Electrolysis", "Compression", "Liquefaction"]),
  chem("Carbon dioxide", "CO2", "Carbon feedstock and climate liability that links capture, fuels, plastics, concrete, and storage.", "Air, flue gas, fermentation, mineral processes", ["Capture", "Regeneration", "Purification", "Compression", "Use or storage"], ["Direct air capture cities", "Synthetic fuel from air and water", "Carbon-negative concrete", "Mars fuel production"], ["Low concentration", "Energy penalty", "Storage verification"], ["Adsorption", "Absorption", "Compression"]),
  chem("Ammonia", "NH3", "Hydrogen carrier, fertilizer backbone, and possible carbon-free shipping fuel.", "Nitrogen plus hydrogen", ["Air separation", "Hydrogen production", "Synthesis", "Storage", "Distribution"], ["Green ammonia fuel", "City-scale nutrient recovery", "Ammonia shipping"], ["Toxicity", "NOx control", "Infrastructure"], ["Air separation", "Catalysis", "Compression"]),
  chem("Methanol", "CH3OH", "Platform molecule for synthetic fuels, chemicals, solvents, and CO2 utilization.", "Syngas or CO2 plus hydrogen", ["Feed cleanup", "Catalytic synthesis", "Separation", "Storage"], ["Synthetic fuel from air and water", "CO2-to-methanol", "Carbon-negative plastics"], ["Hydrogen cost", "Catalyst selectivity", "Product separation"], ["Catalysis", "Distillation", "Heat exchange"]),
  chem("Methane", "CH4", "Fuel, hydrogen feedstock, and Sabatier product for off-world propellant.", "Natural gas, biogas, or CO2 hydrogenation", ["Gas cleanup", "Conversion", "Separation", "Storage"], ["Methane pyrolysis for clean hydrogen", "Mars fuel production", "Thermal batteries"], ["Fugitive emissions", "Carbon handling", "Reactor fouling"], ["Pyrolysis", "Gas separation", "Compression"]),
  chem("Syngas", "CO + H2", "Flexible intermediate for methanol, Fischer-Tropsch fuels, and chemical synthesis.", "Gasification, reforming, or CO2 conversion", ["Feed prep", "Gasification/reforming", "Shift/control", "Cleanup", "Synthesis"], ["Synthetic fuels", "Methanol", "Carbon-derived plastics"], ["Tar/impurity cleanup", "Ratio control", "Capital cost"], ["Gasification", "Catalysis", "Absorption"]),
  chem("Oxygen", "O2", "Oxidant for life support, combustion, medical systems, and off-world propellant.", "Air separation, electrolysis, regolith processing", ["Separation/generation", "Drying", "Compression", "Storage"], ["Lunar oxygen production", "Mars fuel production", "Closed-loop life support"], ["Energy supply", "Purity", "Cryogenic storage"], ["Air separation", "Electrolysis", "Liquefaction"]),
  chem("Nitrogen", "N2", "Inerting gas, ammonia feedstock, semiconductor utility, and habitat atmosphere component.", "Air separation", ["Air intake", "Separation", "Purification", "Compression"], ["Green ammonia fuel", "Semiconductor fabs", "Space habitats"], ["Purity", "Power demand", "Distribution"], ["Air separation", "Membrane separation", "Compression"]),
  chem("Water", "H2O", "Universal solvent, coolant, feedstock, cleaning medium, and life-support loop material.", "Surface water, seawater, air, wastewater, ice", ["Intake", "Treatment", "Polishing", "Reuse", "Discharge"], ["Desalination megastructures", "Wastewater-to-drinking-water systems", "Green hydrogen cities"], ["Scarcity", "Purity requirements", "Brine/waste handling"], ["Filtration", "Membrane separation", "Wastewater treatment"]),
  chem("Sulfuric acid", "H2SO4", "Industrial acid for mining, batteries, fertilizers, and hydrometallurgical extraction.", "Sulfur or sulfide processing", ["Sulfur burning", "SO2 conversion", "Absorption", "Distribution"], ["Battery materials", "Brine mining", "Hydrometallurgy"], ["Corrosion", "Sulfur supply", "Waste acid management"], ["Absorption", "Catalysis", "Leaching"]),
  chem("Sodium hydroxide", "NaOH", "Base for mineralization, water treatment, chemical recycling, and pH control.", "Chlor-alkali electrolysis", ["Brine prep", "Electrolysis", "Separation", "Storage"], ["Carbon-negative concrete", "PFAS destruction systems", "Wastewater treatment"], ["Electricity cost", "Caustic handling", "Chlorine co-product balance"], ["Electrolysis", "Ion exchange", "Precipitation"]),
  chem("Chlorine", "Cl2", "Reactive intermediate for polymers, water disinfection, electronics, and chemical synthesis.", "Chlor-alkali electrolysis", ["Brine prep", "Electrolysis", "Drying", "Use/storage"], ["Water systems", "Semiconductor processing", "Polymer production"], ["Toxicity", "Transport risk", "Demand coupling with caustic"], ["Electrolysis", "Drying", "Absorption"]),
  chem("Silicon", "Si", "Semiconductor and solar backbone for chips, sensors, photovoltaics, and power electronics.", "Quartz reduction and purification", ["Quartz reduction", "Purification", "Crystal growth", "Wafering"], ["Lights-out semiconductor fabs", "Transparent solar windows", "Perovskite/silicon solar"], ["Purity", "Energy intensity", "Fab yield"], ["Crystallization", "Chemical vapor deposition", "Lithography"]),
  chem("Lithium", "Li", "Battery metal for EVs, grid storage, aircraft, drones, and portable future systems.", "Brines, hard rock, clay, recycling", ["Extraction", "Concentration", "Purification", "Conversion", "Cathode/electrolyte use"], ["Grid-scale flow batteries", "Electric aviation", "Wireless road charging"], ["Resource concentration", "Water use", "Refining capacity"], ["Leaching", "Crystallization", "Ion exchange"]),
  chem("Sodium", "Na", "Low-cost battery and chemical platform for storage, caustic, salts, and heat-transfer systems.", "Salt/brine processing", ["Salt purification", "Electrochemical conversion", "Material formulation"], ["Thermal batteries", "Sodium-ion storage", "Chemical production"], ["Energy cost", "Moisture sensitivity", "Material performance"], ["Electrochemical separation", "Drying", "Crystallization"]),
  chem("Nickel", "Ni", "Battery, catalyst, alloy, and high-temperature material for electrified industry.", "Sulfide/laterite ores or recycling", ["Mining", "Leaching/smelting", "Refining", "Precursor production"], ["Electric aviation", "Thermal batteries", "Hydrogen systems"], ["Ore quality", "Processing emissions", "Price volatility"], ["Hydrometallurgy", "Leaching", "Precipitation"]),
  chem("Cobalt", "Co", "Battery and catalyst material where performance competes with supply-chain risk.", "Copper/nickel byproduct mining and recycling", ["Ore processing", "Separation", "Refining", "Cathode precursor"], ["High-energy batteries", "Wearables", "Electric aircraft"], ["Ethical sourcing", "Price volatility", "Recycling"], ["Hydrometallurgy", "Ion exchange", "Precipitation"]),
  chem("Manganese", "Mn", "Battery, steel, and catalyst element for lower-cost energy materials.", "Manganese ores and recycling", ["Ore concentration", "Leaching", "Purification", "Precursor production"], ["Batteries", "Low-carbon steel", "Catalysts"], ["Purity", "Processing waste", "Market scale"], ["Leaching", "Crystallization", "Precipitation"]),
  chem("Copper", "Cu", "Electrical metal for grids, motors, charging, data centers, and thermal systems.", "Ore mining, smelting, solvent extraction/electrowinning, recycling", ["Mining", "Concentration", "Refining", "Wire/foil production"], ["Smart grids", "Wireless road charging", "Data centers"], ["Ore grade decline", "Permitting", "Recycling quality"], ["Flotation", "Leaching", "Electrochemical separation"]),
  chem("Aluminum", "Al", "Lightweight structural and conductive metal for aircraft, buildings, grids, and space systems.", "Bauxite to alumina to electrolytic aluminum", ["Bayer process", "Electrolysis", "Casting", "Forming"], ["Electric aviation", "Space habitats", "Smart buildings"], ["Electricity demand", "Red mud", "Recycling alloys"], ["Calcination", "Electrolysis", "Casting"]),
  chem("Rare earth elements", "REE", "Magnet and optical materials for motors, wind, robotics, displays, and sensors.", "Mineral concentrates and recycling", ["Mining", "Leaching", "Solvent extraction", "Separation", "Metal/alloy production"], ["eVTOL aircraft", "Home robots", "Maglev trains"], ["Separation complexity", "Geographic concentration", "Waste streams"], ["Leaching", "Solvent extraction", "Crystallization"]),
  chem("Graphite", "C", "Battery anode, thermal, electrical, and carbon composite material.", "Natural graphite, synthetic coke routes, recycling", ["Purification", "Spheronization", "Coating", "Anode production"], ["Batteries", "Graphene membranes", "Carbon nanotube fibers"], ["Purity", "Energy intensity", "Supply concentration"], ["Coating", "Sintering", "Purification"]),
  chem("Cement/concrete chemistries", "Ca-Si-Al hydrates", "Structural chemistry for carbon-negative buildings, self-healing concrete, and urban materials.", "Limestone, clays, supplementary cementitious materials, CO2 mineralization", ["Calcination", "Blending", "Hydration", "Curing", "Testing"], ["Carbon-negative concrete", "Self-healing concrete", "3D-printed buildings"], ["CO2 emissions", "Strength certification", "Durability"], ["Calcination", "Curing", "Mineralization"]),
  chem("Polymers", "various", "Structural, flexible, electronic, membrane, and self-healing materials.", "Fossil, biomass, or CO2-derived monomers", ["Monomer synthesis", "Polymerization", "Compounding", "Forming", "Recycling"], ["Carbon-negative plastics", "Smart clothing", "Self-healing polymers"], ["Performance parity", "Recycling", "Additive compatibility"], ["Polymerization", "Extrusion", "Solvent recovery"]),
  chem("Conductive inks", "Ag/Cu/C/polymer", "Printed electronics material for roll-to-roll devices and micromodular circuits.", "Metal particles, carbon materials, polymers, solvents", ["Ink formulation", "Printing", "Drying", "Sintering", "Inspection"], ["Roll-to-roll printed electronics", "Micromodular printed electronics", "Smart clothing"], ["Viscosity control", "Sintering temperature", "Defect density"], ["Coating", "Drying", "Sintering"]),
  chem("Photoresists", "polymer systems", "Pattern-transfer chemistry for semiconductor, display, sensor, and photonic manufacturing.", "Specialty polymers, solvents, photoactive compounds", ["Coating", "Exposure", "Development", "Etch transfer", "Stripping"], ["Lights-out semiconductor fabs", "Photonic computing", "Transparent displays"], ["Resolution", "Defectivity", "Chemical purity"], ["Lithography", "Coating", "Solvent recovery"]),
  chem("Solvents", "various", "Cleaning, synthesis, coating, extraction, and purification media.", "Petrochemical, bio-based, or recycled streams", ["Sourcing", "Use", "Recovery", "Purification", "Reuse"], ["Pharmaceutical factories", "Printed electronics", "Chemical recycling"], ["VOC control", "Purity", "Recovery energy"], ["Distillation", "Solvent recovery", "Drying"]),
  chem("Electrolytes", "salts + solvents", "Ion-transport media for batteries, electrolyzers, fuel cells, and sensors.", "Salts, solvents, polymers, additives", ["Salt purification", "Mixing", "Drying", "Filling", "Sealing"], ["Flow batteries", "Green hydrogen cities", "Smart glass buildings"], ["Stability", "Membrane compatibility", "Purity"], ["Drying", "Filtration", "Electrochemical separation"]),
  chem("Sorbents", "MOFs/amines/zeolites", "Selective capture materials for CO2, water, contaminants, and gases.", "Porous solids, amines, polymers, minerals", ["Synthesis", "Shaping", "Contacting", "Regeneration", "Replacement"], ["Direct air capture cities", "Atmospheric water harvesting", "PFAS destruction systems"], ["Degradation", "Selectivity", "Regeneration energy"], ["Adsorption", "Drying", "Heat exchange"]),
  chem("Membranes", "polymer/ceramic/graphene", "Selective barriers for water, gases, ions, chips, and bioprocessing.", "Polymers, ceramics, graphene, supports", ["Casting/growth", "Pore control", "Module assembly", "Cleaning", "Replacement"], ["Desalination megastructures", "Graphene membranes", "Wastewater-to-drinking-water systems"], ["Fouling", "Defects", "Pressure drop"], ["Membrane separation", "Filtration", "Coating"]),
  chem("Catalysts", "metals/enzymes/oxides", "Kinetic enablers for fuels, hydrogen, chemicals, plastics, and environmental systems.", "Metals, supports, enzymes, oxides", ["Synthesis", "Activation", "Reaction", "Regeneration", "Recovery"], ["Artificial photosynthesis", "Synthetic fuels", "Methane pyrolysis"], ["Lifetime", "Selectivity", "Poisoning"], ["Catalysis", "Calcination", "Filtration"]),
  chem("Biomass-derived feedstocks", "bio-carbon", "Renewable carbon source for fermentation, fuels, polymers, nutrients, and biochar.", "Crops, residues, algae, waste biomass", ["Collection", "Pretreatment", "Conversion", "Purification", "Residue handling"], ["Modular biomanufacturing", "Cultivated meat", "Carbon-negative plastics"], ["Land use", "Variability", "Downstream cost"], ["Fermentation", "Gasification", "Filtration"])
];

function op(name, description, scaleChallenge) {
  return { name, description, appearsIn: [], scaleChallenge };
}

const UNIT_OPERATIONS = [
  op("Electrolysis", "Uses electricity to split or transform chemical species.", "Cost and lifetime depend on power price, catalysts, membranes, and operating current density."),
  op("Catalysis", "Accelerates chemical conversion through engineered active sites.", "Selectivity, poisoning, heat management, and catalyst lifetime control economics."),
  op("Adsorption", "Captures molecules on selective solid surfaces.", "Capacity, regeneration energy, humidity, and degradation often dominate scale-up."),
  op("Absorption", "Transfers gases into liquids for capture or reaction.", "Solvent loss, heat duty, corrosion, and mass transfer determine viability."),
  op("Distillation", "Separates liquids by volatility.", "Energy intensity and azeotropes can dominate process cost."),
  op("Crystallization", "Forms purified solids from solution or melt.", "Nucleation control, impurity rejection, and particle handling are hard to scale."),
  op("Membrane separation", "Separates by size, charge, solubility, or diffusivity.", "Fouling, defects, pressure drop, and module sealing decide reliability."),
  op("Filtration", "Removes particles, cells, or solids from fluids.", "Cake formation, cleaning cycles, and variable feeds limit uptime."),
  op("Drying", "Removes solvent or water from solids, films, gases, or products.", "Energy use, cracking, residual solvent, and throughput set constraints."),
  op("Calcination", "Thermally decomposes or activates solids.", "High-temperature heat, emissions, and solid residence time matter."),
  op("Pyrolysis", "Thermally decomposes feedstocks without oxygen.", "Reactor fouling, heat transfer, and product handling are scale risks."),
  op("Gasification", "Converts carbonaceous feedstocks into synthesis gas.", "Feed variability, tar control, and gas cleanup dominate complexity."),
  op("Fermentation", "Uses organisms or enzymes to convert feedstocks.", "Contamination, oxygen transfer, sterility, and downstream recovery drive cost."),
  op("Polymerization", "Links monomers into polymers.", "Heat removal, molecular weight control, and residual monomer limits matter."),
  op("Lithography", "Patterns materials for chips and microdevices.", "Resolution, overlay, particle defects, and photoresist chemistry set yield."),
  op("Chemical vapor deposition", "Deposits thin films from vapor-phase chemistry.", "Uniformity, precursor purity, and tool uptime control device quality."),
  op("Physical vapor deposition", "Deposits films by sputtering or evaporation.", "Film stress, adhesion, and uniformity limit scale."),
  op("Atomic layer deposition", "Deposits ultrathin conformal layers by sequential surface reactions.", "Cycle time, precursor cost, and defect density matter."),
  op("Coating", "Applies functional layers to substrates.", "Uniformity, adhesion, drying, and inline inspection define manufacturability."),
  op("Curing", "Sets a material through heat, light, moisture, or chemical reaction.", "Incomplete cure, shrinkage, and durability define quality."),
  op("Sintering", "Densifies particles with heat or light.", "Temperature compatibility, shrinkage, and conductivity control device performance."),
  op("Annealing", "Thermally treats materials to improve structure or properties.", "Thermal budgets, atmosphere, and stress control matter."),
  op("Extrusion", "Forces material through a die to form continuous products.", "Rheology, die swell, cooling, and additive dispersion set quality."),
  op("Compression", "Raises gas pressure for storage, reaction, or transport.", "Energy use, leakage, heat rejection, and safety shape design."),
  op("Liquefaction", "Converts gases into cryogenic liquids.", "Energy penalty, boiloff, insulation, and safety dominate deployment."),
  op("Heat exchange", "Transfers heat between streams or storage media.", "Fouling, pinch temperature, materials, and integration determine performance."),
  op("Combustion", "Releases heat through oxidation.", "Emissions, flame stability, NOx, and safety constrain future fuels."),
  op("Plasma processing", "Uses ionized gas for conversion, etching, or destruction.", "Power efficiency, electrode life, and scale-up uniformity are key."),
  op("Sterilization", "Destroys microbes for medical and bioprocess systems.", "Material compatibility, validation, and sterility assurance constrain operations."),
  op("Solvent recovery", "Recovers and purifies solvent for reuse.", "Energy use, water content, impurities, and VOC control drive design."),
  op("Wastewater treatment", "Removes organics, nutrients, pathogens, and trace contaminants.", "Variable feeds, monitoring, sludge, and failure safety matter."),
  op("Air separation", "Separates air into nitrogen, oxygen, argon, or other streams.", "Power demand, purity, and integration determine economics."),
  op("Ion exchange", "Swaps ions on resin or functional materials.", "Selectivity, regeneration chemicals, fouling, and brine waste matter."),
  op("Precipitation", "Forms solids from dissolved species.", "Selectivity, particle size, impurities, and solid-liquid separation drive quality."),
  op("Leaching", "Dissolves target species from solids.", "Reagent use, kinetics, impurity co-dissolution, and waste handling dominate."),
  op("Hydrometallurgy", "Extracts and refines metals in aqueous systems.", "Selectivity, reagent recycle, residue management, and purity set scale."),
  op("Electrochemical separation", "Uses electrical potential to separate or transform ions.", "Membrane life, current efficiency, and impurity management control economics.")
];

const BOTTLENECK_TAXONOMY = [
  "energy penalty",
  "material degradation",
  "low yield",
  "poor selectivity",
  "slow kinetics",
  "fouling",
  "heat management",
  "mass-transfer limitation",
  "separation cost",
  "purity requirement",
  "infrastructure gap",
  "safety risk",
  "regulatory barrier",
  "reliability gap",
  "supply-chain constraint",
  "cost curve problem",
  "public acceptance",
  "maintenance burden",
  "data/control problem",
  "manufacturing repeatability",
  "quality-control challenge",
  "lifecycle/recycling issue",
  "extreme environment durability",
  "scale-up uncertainty"
];

const FEATURED_CASE_IDS = [
  "micromodular-printed-electronics",
  "smart-glass-buildings",
  "synthetic-fuel-from-air-and-water",
  "carbon-negative-concrete",
  "lights-out-semiconductor-fabs",
  "atmospheric-water-harvesting",
  "green-ammonia-fuel",
  "urban-vertical-farms",
  "autonomous-waste-sorting-facilities",
  "lunar-oxygen-production",
  "mars-fuel-production"
];

function slugifyAtlas(value) {
  return String(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function textForTech(tech) {
  return [
    tech.name,
    tech.category,
    tech.promise,
    tech.realisticPathway,
    tech.readinessGap,
    tech.scaleCondition,
    tech.pfdSteps.join(" "),
    tech.inputs.join(" "),
    tech.outputs.join(" "),
    tech.bottlenecks.join(" ")
  ].join(" ").toLowerCase().normalize("NFKC").replace(/\s+/g, " ");
}

function hasAny(text, words) {
  return words.some((word) => text.includes(word));
}

function unique(values) {
  return Array.from(new Set(values.filter(Boolean)));
}

function sectorFor(tech) {
  const text = textForTech(tech);
  const name = (tech.name || "").toLowerCase().normalize("NFKC");
  if (tech.category === "Space" || hasAny(name, ["lunar", "mars", "orbital", "asteroid", "space elevator", "space habitat", "terraforming"])) return "Space and Off-World Industry";
  if (tech.category === "Transportation") return "Transportation and Mobility";
  if (tech.category === "Medical Tech" || (tech.category === "Bio" && !name.includes("living building"))) return "Biomanufacturing, Medicine, and Human Augmentation";
  if (tech.category === "Computing" || hasAny(name, ["semiconductor", "quantum", "neuromorphic", "ai assistant", "immersive vr", "augmented reality", "real-time translation", "scientific discovery", "mind archives", "transparent displays", "holographic"])) return "Computing, Semiconductors, and Ambient Intelligence";
  if (hasAny(name, ["atmospheric water", "desalination", "brine mining", "self-cleaning city water", "pfas", "wastewater", "nutrient recovery", "stormwater", "emergency water", "closed-loop building water"]) || hasAny(text, ["reverse osmosis", "potable storage"])) return "Future Water Systems";
  if (name.includes("living building")) return "Future Cities and Built Environments";
  if (hasAny(name, ["direct air capture", "synthetic fuel", "carbon-negative", "low-carbon steel", "low-carbon", "methane pyrolysis"]) || hasAny(text, ["co2 capture", "captured carbon", "fischer-tropsch", "mineralization reactor"])) return "Carbon and Atmospheric Engineering";
  if (tech.category === "Energy" || hasAny(name, ["fusion", "solar power", "hydrogen", "ammonia", "battery", "geothermal", "thermal batteries"]) || name.includes("industrial waste-heat")) return "Clean Energy Civilization";
  if (tech.category === "Materials" || hasAny(name, ["smart glass", "radiative cooling", "self-healing", "adaptive building skins", "transparent solar", "graphene", "carbon nanotube", "metamaterial", "aerogel", "shape-shifting", "anti-icing", "self-cleaning surfaces"])) return "Future Materials and Smart Surfaces";
  if (tech.category === "Manufacturing" || tech.category === "Robotics" || hasAny(name, ["factory", "robot", "printed", "additive", "fab", "microfactory", "construction"])) return "Advanced Manufacturing and Microfactories";
  return "Future Cities and Built Environments";
}

function inferChemicals(tech) {
  const text = textForTech(tech);
  const chemicals = [];
  if (hasAny(text, ["hydrogen", "electrolysis", "fuel cell", "h2"])) chemicals.push("Hydrogen");
  if (hasAny(text, ["co2", "carbon", "air capture", "mineralization"])) chemicals.push("Carbon dioxide");
  if (text.includes("ammonia") || text.includes("nitrogen")) chemicals.push("Ammonia", "Nitrogen");
  if (text.includes("methanol")) chemicals.push("Methanol");
  if (text.includes("methane") || text.includes("sabatier")) chemicals.push("Methane");
  if (text.includes("syngas") || text.includes("fischer")) chemicals.push("Syngas");
  if (hasAny(text, ["oxygen", "o2", "life support", "regolith"])) chemicals.push("Oxygen");
  if (hasAny(text, ["water", "desalination", "wastewater", "hydroponic", "electrolysis"])) chemicals.push("Water");
  if (hasAny(text, ["silicon", "semiconductor", "wafer", "solar"])) chemicals.push("Silicon", "Photoresists");
  if (hasAny(text, ["battery", "lithium", "electric aviation", "ev"])) chemicals.push("Lithium", "Electrolytes", "Graphite");
  if (hasAny(text, ["cobalt", "nickel", "manganese", "cathode"])) chemicals.push("Nickel", "Cobalt", "Manganese");
  if (hasAny(text, ["copper", "grid", "charging", "electronics", "conductive"])) chemicals.push("Copper");
  if (hasAny(text, ["aluminum", "aircraft", "lightweight", "space habitat"])) chemicals.push("Aluminum");
  if (hasAny(text, ["magnet", "motor", "levitation", "rare earth"])) chemicals.push("Rare earth elements");
  if (hasAny(text, ["concrete", "cement", "curing"])) chemicals.push("Cement/concrete chemistries");
  if (hasAny(text, ["polymer", "plastic", "textile", "smart clothing", "self-healing"])) chemicals.push("Polymers");
  if (hasAny(text, ["printed electronics", "ink", "roll-to-roll", "micromodular"])) chemicals.push("Conductive inks", "Solvents");
  if (hasAny(text, ["sorbent", "adsorption", "capture"])) chemicals.push("Sorbents");
  if (hasAny(text, ["membrane", "filtration", "reverse osmosis"])) chemicals.push("Membranes");
  if (hasAny(text, ["catalyst", "catalytic", "artificial photosynthesis"])) chemicals.push("Catalysts");
  if (hasAny(text, ["biomass", "fermentation", "cultivated", "algae", "bio"])) chemicals.push("Biomass-derived feedstocks");
  if (chemicals.length < 2) chemicals.push("Water", "Catalysts");
  return unique(chemicals).slice(0, 6);
}

function inferMaterials(tech, chemicals) {
  const text = textForTech(tech);
  const materials = [];
  if (hasAny(text, ["glass", "window"])) materials.push("Glass", "Transparent conductors");
  if (hasAny(text, ["membrane", "graphene"])) materials.push("Membrane modules", "Graphene");
  if (hasAny(text, ["concrete", "cement"])) materials.push("Cementitious materials", "Mineral aggregates");
  if (hasAny(text, ["battery", "electrolyte"])) materials.push("Electrodes", "Electrolytes");
  if (hasAny(text, ["chip", "semiconductor", "display"])) materials.push("Silicon wafers", "Photoresists", "Thin films");
  if (hasAny(text, ["coating", "surface", "anti-icing", "radiative"])) materials.push("Functional coatings", "Binders");
  if (hasAny(text, ["textile", "clothing", "wearable"])) materials.push("Smart textiles", "Flexible electronics");
  if (hasAny(text, ["metal", "steel", "aircraft", "maglev"])) materials.push("Metals and alloys");
  if (hasAny(text, ["bioreactor", "cell", "organ", "meat"])) materials.push("Growth media", "Scaffolds");
  chemicals.forEach((item) => {
    if (["Polymers", "Membranes", "Conductive inks", "Sorbents", "Catalysts", "Electrolytes"].includes(item)) materials.push(item);
  });
  return unique(materials).slice(0, 5);
}

function inferUnitOperations(tech) {
  const text = textForTech(tech);
  const ops = [];
  const checks = [
    ["electrolysis", "Electrolysis"],
    ["catalyst", "Catalysis"],
    ["catalytic", "Catalysis"],
    ["adsorption", "Adsorption"],
    ["sorbent", "Adsorption"],
    ["absorption", "Absorption"],
    ["distillation", "Distillation"],
    ["crystallization", "Crystallization"],
    ["membrane", "Membrane separation"],
    ["filtration", "Filtration"],
    ["drying", "Drying"],
    ["calcination", "Calcination"],
    ["pyrolysis", "Pyrolysis"],
    ["gasification", "Gasification"],
    ["fermentation", "Fermentation"],
    ["polymerization", "Polymerization"],
    ["lithography", "Lithography"],
    ["chemical vapor", "Chemical vapor deposition"],
    ["physical vapor", "Physical vapor deposition"],
    ["atomic layer", "Atomic layer deposition"],
    ["coating", "Coating"],
    ["curing", "Curing"],
    ["sintering", "Sintering"],
    ["annealing", "Annealing"],
    ["extrusion", "Extrusion"],
    ["compression", "Compression"],
    ["liquefaction", "Liquefaction"],
    ["heat", "Heat exchange"],
    ["combustion", "Combustion"],
    ["plasma", "Plasma processing"],
    ["sterilization", "Sterilization"],
    ["solvent", "Solvent recovery"],
    ["wastewater", "Wastewater treatment"],
    ["air separation", "Air separation"],
    ["ion exchange", "Ion exchange"],
    ["precipitation", "Precipitation"],
    ["leaching", "Leaching"],
    ["hydrometallurgy", "Hydrometallurgy"],
    ["electrochemical", "Electrochemical separation"]
  ];
  checks.forEach(([needle, opName]) => {
    if (text.includes(needle)) ops.push(opName);
  });
  if (tech.category === "Energy") ops.push("Electrolysis", "Heat exchange", "Compression");
  if (tech.category === "Climate Tech") ops.push("Adsorption", "Catalysis", "Compression");
  if (tech.category === "Infrastructure") ops.push("Membrane separation", "Filtration", "Wastewater treatment");
  if (tech.category === "Materials") ops.push("Coating", "Curing", "Filtration");
  if (tech.category === "Manufacturing") ops.push("Coating", "Drying", "Inspection");
  if (tech.category === "Bio" || tech.category === "Medical Tech") ops.push("Fermentation", "Filtration", "Sterilization");
  if (tech.category === "Space") ops.push("Electrolysis", "Compression", "Heat exchange");
  return unique(ops).filter((name) => UNIT_OPERATIONS.some((opItem) => opItem.name === name)).slice(0, 6);
}


function inferCriticalParameters(tech) {
  const text = textForTech(tech);
  const params = [];
  if (hasAny(text, ["hydrogen", "ammonia", "methane", "co2", "gas", "air"])) params.push("purity", "pressure", "leak rate");
  if (hasAny(text, ["heat", "thermal", "fusion", "pyrolysis", "combustion", "geothermal"])) params.push("temperature", "heat flux", "residence time");
  if (hasAny(text, ["water", "desalination", "wastewater", "pfas", "membrane", "filtration"])) params.push("flux", "recovery ratio", "fouling rate");
  if (hasAny(text, ["coating", "glass", "display", "semiconductor", "printed", "lithography", "electronics", "surface"])) params.push("film thickness", "defect density", "line width / registration");
  if (hasAny(text, ["battery", "electrolyte", "electrolysis", "fuel cell", "electrochemical"])) params.push("current density", "voltage efficiency", "cycle life");
  if (hasAny(text, ["bioreactor", "cell", "fermentation", "organ", "cultivated", "medical"])) params.push("sterility", "cell density", "viability", "residence time");
  if (hasAny(text, ["concrete", "building", "road", "construction"])) params.push("strength", "curing time", "durability");
  if (hasAny(text, ["robot", "autonomous", "ai", "digital twin", "sensor"])) params.push("uptime", "sensor drift", "control latency");
  if (params.length < 4) params.push("yield", "throughput", "unit cost", "reliability");
  return unique(params).slice(0, 6);
}

function inferBottleneckTags(tech) {
  const text = textForTech(tech);
  const tags = [];
  if (hasAny(text, ["energy", "electricity", "power", "heat", "efficiency"])) tags.push("energy penalty");
  if (hasAny(text, ["degradation", "durability", "lifetime", "abrasion", "fatigue"])) tags.push("material degradation");
  if (hasAny(text, ["yield", "repeatability", "defect"])) tags.push("low yield", "manufacturing repeatability");
  if (hasAny(text, ["selectivity", "purity"])) tags.push("poor selectivity", "purity requirement");
  if (hasAny(text, ["fouling", "contamination"])) tags.push("fouling");
  if (hasAny(text, ["thermal", "heat"])) tags.push("heat management");
  if (hasAny(text, ["separation", "purification", "downstream"])) tags.push("separation cost");
  if (hasAny(text, ["infrastructure", "distribution", "pipeline", "grid", "airport", "city", "retrofit"])) tags.push("infrastructure gap");
  if (hasAny(text, ["safety", "toxicity", "leakage", "nox", "cryogenic"])) tags.push("safety risk");
  if (hasAny(text, ["regulation", "regulatory", "code", "certification", "standards", "permitting"])) tags.push("regulatory barrier");
  if (hasAny(text, ["reliability", "maintenance", "robust"])) tags.push("reliability gap", "maintenance burden");
  if (hasAny(text, ["supply", "feedstock", "critical", "resource"])) tags.push("supply-chain constraint");
  if (hasAny(text, ["cost", "economics", "market", "capital"])) tags.push("cost curve problem");
  if (hasAny(text, ["public", "trust", "acceptance", "social"])) tags.push("public acceptance");
  if (hasAny(text, ["sensor", "data", "control", "model", "autonomy"])) tags.push("data/control problem");
  if (hasAny(text, ["qa", "quality", "inspection", "validation"])) tags.push("quality-control challenge");
  if (hasAny(text, ["recycle", "recycling", "lifecycle"])) tags.push("lifecycle/recycling issue");
  if (hasAny(text, ["space", "lunar", "mars", "radiation", "dust", "icing", "harsh"])) tags.push("extreme environment durability");
  tags.push("scale-up uncertainty");
  return unique(tags).filter((tag) => BOTTLENECK_TAXONOMY.includes(tag)).slice(0, 4);
}

function inferReadiness(tech, sector, bottleneckTags) {
  const text = textForTech(tech);
  let trl = 5;
  if (hasAny(text, ["commercial", "mature", "exist", "proven", "fielded"])) trl += 2;
  if (hasAny(text, ["prototype", "pilot", "demonstration", "trial"])) trl += 1;
  if (hasAny(text, ["speculative", "far away", "unproven", "not yet", "no broadly verified"])) trl -= 2;
  if (sector === "Space and Off-World Industry") trl -= 1;
  trl = Math.max(1, Math.min(9, trl));

  let mrl = Math.max(1, Math.min(9, trl - (hasAny(text, ["manufacturing", "repeatable", "yield", "defect", "quality"]) ? 2 : 1)));
  let irl = Math.max(1, Math.min(9, trl - (bottleneckTags.includes("infrastructure gap") ? 3 : 1)));
  if (hasAny(text, ["city", "grid", "airport", "pipeline", "district", "space", "orbital"])) irl = Math.max(1, irl - 1);

  const biggestGap = bottleneckTags.includes("infrastructure gap")
    ? "Infrastructure readiness"
    : bottleneckTags.includes("manufacturing repeatability") || bottleneckTags.includes("quality-control challenge")
      ? "Manufacturing readiness"
      : bottleneckTags.includes("energy penalty") || bottleneckTags.includes("cost curve problem")
        ? "Process economics"
        : "Reliability at scale";
  return { trl, mrl, irl, biggestGap };
}

const rawTechnologies = technologies.map((tech) => ({ ...tech }));
let enrichedTechnologies = technologies.map((tech) => {
  const id = slugifyAtlas(tech.name);
  const sector = sectorFor(tech);
  const chemicals = inferChemicals(tech);
  const materials = inferMaterials(tech, chemicals);
  const unitOperations = inferUnitOperations(tech);
  const bottleneckTags = inferBottleneckTags(tech);
  const criticalParameters = inferCriticalParameters(tech);
  return {
    id,
    name: tech.name,
    category: sector,
    originalCategory: tech.category,
    subcategory: tech.category,
    sciFiPromise: tech.promise,
    promise: tech.promise,
    realisticPathway: tech.realisticPathway,
    pfdSteps: tech.pfdSteps,
    inputs: tech.inputs,
    outputs: tech.outputs,
    chemicals,
    materials,
    unitOperations,
    criticalParameters,
    bottlenecks: tech.bottlenecks,
    bottleneckTags,
    readiness: inferReadiness(tech, sector, bottleneckTags),
    readinessGap: tech.readinessGap,
    scaleCondition: tech.scaleCondition,
    processQuestion: tech.processQuestion,
    relatedTechnologies: [],
    featured: FEATURED_CASE_IDS.includes(id)
  };
});

enrichedTechnologies = enrichedTechnologies.map((tech) => ({
  ...tech,
  relatedTechnologies: enrichedTechnologies
    .filter((candidate) => candidate.id !== tech.id && (candidate.category === tech.category || candidate.unitOperations.some((opName) => tech.unitOperations.includes(opName))))
    .slice(0, 4)
    .map((candidate) => candidate.id)
}));

const enrichedChemicals = CHEMICAL_SPINE.map((chemical) => ({
  ...chemical,
  relatedTechnologies: enrichedTechnologies
    .filter((tech) => tech.chemicals.includes(chemical.name))
    .slice(0, 8)
    .map((tech) => tech.id)
}));

const enrichedUnitOperations = UNIT_OPERATIONS.map((operation) => ({
  ...operation,
  appearsIn: enrichedTechnologies
    .filter((tech) => tech.unitOperations.includes(operation.name))
    .slice(0, 10)
    .map((tech) => tech.id)
}));

window.FUTURE_SYSTEMS_ATLAS = {
  categoryMeta: CATEGORY_META,
  sectors: SECTOR_META,
  processPathways: PROCESS_PATHWAYS,
  masterStack: MASTER_STACK,
  chemicals: enrichedChemicals,
  unitOperations: enrichedUnitOperations,
  bottleneckTaxonomy: BOTTLENECK_TAXONOMY,
  featuredCaseIds: FEATURED_CASE_IDS,
  rawTechnologies,
  technologies: enrichedTechnologies
};
